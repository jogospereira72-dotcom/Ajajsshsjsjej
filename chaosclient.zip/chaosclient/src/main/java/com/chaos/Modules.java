package com.chaos;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.AbstractSkeletonEntity;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.EndermanEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.SlimeEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.BatEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.List;
import java.util.Random;
import java.util.function.Consumer;
import java.util.function.Predicate;

public final class Modules {
    private static final Random R = new Random();
    private static boolean prevJump;
    private static List<Module> L;

    private Modules() {}

    public static void registerAll(List<Module> out) {
        L = out;
        movement();
        fun();
        visual();
        combat();
        utility();
    }

    // ---------- helpers ----------
    static void add(String n, String d, Consumer<MinecraftClient> t) { L.add(new LambdaModule(n, d, t, null)); }
    static void add(String n, String d, Consumer<MinecraftClient> t, Consumer<MinecraftClient> off) { L.add(new LambdaModule(n, d, t, off)); }

    static boolean moving(MinecraftClient mc) {
        var o = mc.options;
        return o.forwardKey.isPressed() || o.backKey.isPressed() || o.leftKey.isPressed() || o.rightKey.isPressed();
    }
    static void vy(MinecraftClient mc, double y) { Vec3d v = mc.player.getVelocity(); mc.player.setVelocity(v.x, y, v.z); }
    static void hscale(MinecraftClient mc, double k, double max) {
        Vec3d v = mc.player.getVelocity();
        double h = Math.hypot(v.x, v.z);
        if (h < 1e-4) return;
        double nh = k >= 1 ? Math.min(h * k, Math.max(max, h)) : h * k;
        double s = nh / h;
        mc.player.setVelocity(v.x * s, v.y, v.z * s);
    }
    static void hset(MinecraftClient mc, double speed) {
        Vec3d v = mc.player.getVelocity();
        double h = Math.hypot(v.x, v.z);
        if (h < 1e-4 || h <= speed) return;
        double s = speed / h;
        mc.player.setVelocity(v.x * s, v.y, v.z * s);
    }
    static long t(MinecraftClient mc) { return mc.world.getTime(); }
    static boolean ready(MinecraftClient mc) { return mc.player.getAttackCooldownProgress(0f) >= 1f; }
    static void hit(MinecraftClient mc, Entity e) { mc.interactionManager.attackEntity(mc.player, e); mc.player.swingHand(Hand.MAIN_HAND); }
    static Entity nearest(MinecraftClient mc, Predicate<Entity> f, double range) {
        Entity best = null; double bd = range;
        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player || !f.test(e)) continue;
            double d = mc.player.distanceTo(e);
            if (d < bd) { bd = d; best = e; }
        }
        return best;
    }
    static void face(MinecraftClient mc, Entity e) {
        double dx = e.getX() - mc.player.getX(), dz = e.getZ() - mc.player.getZ();
        double dy = (e.getY() + e.getHeight() * 0.85) - mc.player.getEyeY();
        mc.player.setYaw((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90));
        mc.player.setPitch((float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz))));
    }
    static void push(MinecraftClient mc, Entity from, double force) {
        Vec3d a = new Vec3d(mc.player.getX() - from.getX(), 0, mc.player.getZ() - from.getZ());
        if (a.lengthSquared() < 1e-6) return;
        a = a.normalize();
        Vec3d v = mc.player.getVelocity();
        mc.player.setVelocity(v.x + a.x * force, v.y, v.z + a.z * force);
    }
    static void glow(MinecraftClient mc, Predicate<Entity> f, boolean on) {
        if (mc.world == null) return;
        for (Entity e : mc.world.getEntities()) if (e != mc.player && f.test(e)) e.setGlowing(on);
    }
    static void esp(String n, String d, Predicate<Entity> f) {
        add(n, d, mc -> glow(mc, f, true), mc -> glow(mc, f, false));
    }

    // ---------- MOVIMENTO (36) ----------
    static void movement() {
        add("Speed", "Acelera ao andar no chão", mc -> { if (moving(mc) && mc.player.isOnGround()) hscale(mc, 1.15, 0.7); });
        add("Glide", "Planar devagar", mc -> { if (!mc.player.isOnGround() && mc.player.getVelocity().y < -0.05) vy(mc, -0.05); });
        add("Jetpack", "Segure pulo no ar para subir", mc -> { if (mc.options.jumpKey.isPressed() && !mc.player.isOnGround()) vy(mc, 0.3); });
        add("Hover", "Sneak no ar = parar no ar", mc -> { if (!mc.player.isOnGround() && mc.options.sneakKey.isPressed()) vy(mc, 0); });
        add("Spider", "Escala paredes", mc -> { if (mc.player.horizontalCollision && mc.options.forwardKey.isPressed()) vy(mc, 0.2); });
        add("Jesus", "Anda na água", mc -> { if (mc.player.isTouchingWater() && !mc.options.sneakKey.isPressed()) vy(mc, 0.11); });
        add("HighJump", "Pulo gigante", mc -> { if (mc.player.isOnGround() && mc.options.jumpKey.isPressed()) vy(mc, 0.85); });
        add("LongJump", "Pulo longo", mc -> { if (mc.player.isOnGround() && mc.options.jumpKey.isPressed() && moving(mc)) hscale(mc, 2.0, 1.2); });
        add("AirJump", "Pulo infinito no ar", mc -> {
            boolean j = mc.options.jumpKey.isPressed();
            if (j && !prevJump && !mc.player.isOnGround()) vy(mc, 0.42);
            prevJump = j;
        });
        add("Dolphin", "Nada como golfinho", mc -> { if (mc.player.isTouchingWater() && moving(mc)) vy(mc, Math.min(mc.player.getVelocity().y + 0.04, 0.3)); });
        add("Parkour", "Pula sozinho na beira dos blocos", mc -> {
            Vec3d f = mc.player.getRotationVector();
            double l = Math.hypot(f.x, f.z);
            if (l < 1e-4 || !mc.player.isOnGround() || !mc.options.forwardKey.isPressed()) return;
            BlockPos ahead = BlockPos.ofFloored(mc.player.getX() + f.x / l * 0.7, mc.player.getY() - 0.5, mc.player.getZ() + f.z / l * 0.7);
            if (mc.world.getBlockState(ahead).isAir()) vy(mc, 0.42);
        });
        add("AutoWalk", "Anda sozinho pra frente", mc -> mc.options.forwardKey.setPressed(true), mc -> mc.options.forwardKey.setPressed(false));
        add("AutoJump", "Pula obstáculos sozinho", mc -> { if (mc.player.isOnGround() && mc.player.horizontalCollision) vy(mc, 0.42); });
        add("AutoSneak", "Fica agachado", mc -> mc.options.sneakKey.setPressed(true), mc -> mc.options.sneakKey.setPressed(false));
        add("Snail", "ABSURDO: vira uma lesma", mc -> hscale(mc, 0.5, 0));
        add("Statue", "ABSURDO: vira estátua (para na horizontal)", mc -> { Vec3d v = mc.player.getVelocity(); mc.player.setVelocity(0, v.y, 0); });
        add("Pogo", "ABSURDO: pula sem parar bem alto", mc -> { if (mc.player.isOnGround()) vy(mc, 0.9); });
        add("Sink", "Afunda na água", mc -> { if (mc.player.isTouchingWater()) vy(mc, -0.25); });
        add("Levitate", "Levita devagar", mc -> vy(mc, 0.1));
        add("Dash", "Impulso pra frente a cada 1s", mc -> {
            Vec3d f = mc.player.getRotationVector();
            double l = Math.hypot(f.x, f.z);
            if (l < 1e-4 || t(mc) % 20 != 0 || !mc.options.forwardKey.isPressed()) return;
            Vec3d v = mc.player.getVelocity();
            mc.player.setVelocity(v.x + f.x / l * 1.2, v.y, v.z + f.z / l * 1.2);
        });
        add("Zoomies", "ABSURDO: modo zoomies", mc -> { if (moving(mc)) hscale(mc, 1.3, 1.0); });
        add("Glue", "Para instantaneamente ao soltar as teclas", mc -> {
            if (!moving(mc) && mc.player.isOnGround()) { Vec3d v = mc.player.getVelocity(); mc.player.setVelocity(0, v.y, 0); }
        });
        add("Trampoline", "ABSURDO: o chão vira trampolim", mc -> { if (mc.player.isOnGround()) vy(mc, 1.2); });
        add("GroundPound", "Sneak no ar = voadora pra baixo", mc -> { if (!mc.player.isOnGround() && mc.options.sneakKey.isPressed()) vy(mc, -2.0); });
        add("Hiccup", "ABSURDO: soluço (pulinho a cada 2s)", mc -> { if (t(mc) % 40 == 0 && mc.player.isOnGround()) vy(mc, 0.42); });
        add("Sloth", "ABSURDO: preguiça (velocidade máxima baixa)", mc -> hset(mc, 0.05));
        add("Earthquake", "ABSURDO: terremoto (você treme)", mc -> {
            Vec3d v = mc.player.getVelocity();
            mc.player.setVelocity(v.x + (R.nextDouble() - 0.5) * 0.3, v.y, v.z + (R.nextDouble() - 0.5) * 0.3);
        });
        add("Drunk", "ABSURDO: bêbado (câmera e passos tortos)", mc -> {
            mc.player.setYaw(mc.player.getYaw() + (R.nextFloat() - 0.5f) * 6f);
            Vec3d v = mc.player.getVelocity();
            mc.player.setVelocity(v.x + (R.nextDouble() - 0.5) * 0.05, v.y, v.z + (R.nextDouble() - 0.5) * 0.05);
        });
        add("Catapult", "Pulo + sneak no chão = catapulta", mc -> {
            if (!mc.player.isOnGround() || !mc.options.jumpKey.isPressed() || !mc.options.sneakKey.isPressed()) return;
            Vec3d f = mc.player.getRotationVector();
            mc.player.setVelocity(f.x * 1.5, 1.5, f.z * 1.5);
        });
        add("Flutter", "ABSURDO: balança no ar como borboleta", mc -> { if (!mc.player.isOnGround()) vy(mc, Math.sin(t(mc) * 0.5) * 0.2); });
        add("WallJump", "Pula na parede", mc -> { if (mc.player.horizontalCollision && !mc.player.isOnGround() && mc.options.jumpKey.isPressed()) vy(mc, 0.42); });
        add("Step", "Sobe degraus altos", mc -> { if (mc.player.horizontalCollision && mc.player.isOnGround()) vy(mc, 0.6); });
        add("Kangaroo", "ABSURDO: salta pra frente igual canguru", mc -> {
            if (!mc.player.isOnGround() || !mc.options.forwardKey.isPressed()) return;
            Vec3d f = mc.player.getRotationVector();
            double l = Math.hypot(f.x, f.z);
            if (l < 1e-4) return;
            mc.player.setVelocity(f.x / l * 0.6, 0.6, f.z / l * 0.6);
        });
        add("Hoverboard", "Sneak + andar no ar = hoverboard", mc -> {
            if (!mc.player.isOnGround() && mc.options.sneakKey.isPressed() && moving(mc)) { vy(mc, 0); hscale(mc, 1.05, 0.8); }
        });
        add("Mosquito", "ABSURDO: voa zumbindo igual mosquito", mc -> {
            mc.player.setVelocity((R.nextDouble() - 0.5) * 0.2, 0.05, (R.nextDouble() - 0.5) * 0.2);
        });
        add("Frog", "ABSURDO: pulo de sapo a cada 1s", mc -> { if (mc.player.isOnGround() && t(mc) % 20 == 0) vy(mc, 1.0); });
    }

    // ---------- ROTAÇÃO / DIVERSÃO ABSURDA (25) ----------
    static void fun() {
        add("HeadBang", "ABSURDO: headbang", mc -> mc.player.setPitch((float) (Math.sin(t(mc) * 0.4) * 45)));
        add("Wobble", "ABSURDO: câmera balança", mc -> mc.player.setYaw(mc.player.getYaw() + (float) (Math.sin(t(mc) * 0.3) * 4)));
        add("Shiver", "ABSURDO: tremedeira de frio", mc -> {
            mc.player.setYaw(mc.player.getYaw() + (R.nextFloat() - 0.5f) * 4f);
            mc.player.setPitch(mc.player.getPitch() + (R.nextFloat() - 0.5f) * 2f);
        });
        add("Dance", "ABSURDO: dança (gira e agacha)", mc -> {
            mc.player.setYaw(mc.player.getYaw() + 10);
            mc.options.sneakKey.setPressed(t(mc) % 10 < 5);
        }, mc -> mc.options.sneakKey.setPressed(false));
        add("Beyblade", "ABSURDO: giro ultra rápido", mc -> mc.player.setYaw(mc.player.getYaw() + 60));
        add("Cartwheel", "ABSURDO: cambalhota de câmera", mc -> mc.player.setPitch((float) (((t(mc) * 15) % 180) - 90)));
        add("LookDown", "Olha sempre pra baixo", mc -> mc.player.setPitch(90));
        add("LookUp", "Olha sempre pra cima", mc -> mc.player.setPitch(-90));
        add("Compass", "Trava a direção em múltiplos de 90°", mc -> mc.player.setYaw(Math.round(mc.player.getYaw() / 90f) * 90f));
        add("SneakSpam", "ABSURDO: agacha e levanta sem parar", mc -> mc.options.sneakKey.setPressed(t(mc) % 2 == 0), mc -> mc.options.sneakKey.setPressed(false));
        add("SwingSpam", "ABSURDO: balança o braço sem parar", mc -> mc.player.swingHand(Hand.MAIN_HAND));
        add("Panic", "ABSURDO: corre em pânico em direções aleatórias", mc -> {
            if (t(mc) % 10 == 0) mc.player.setYaw(R.nextFloat() * 360f);
            mc.options.forwardKey.setPressed(true);
        }, mc -> mc.options.forwardKey.setPressed(false));
        add("Sneeze", "ABSURDO: espirra (pulinho + giro) a cada 3s", mc -> {
            if (t(mc) % 60 != 0) return;
            mc.player.setPitch(-30);
            mc.player.setYaw(mc.player.getYaw() + R.nextInt(60) - 30);
            vy(mc, 0.3);
        });
        add("ItemRain", "ABSURDO: joga o item da mão fora sem parar", mc -> { if (t(mc) % 5 == 0) mc.player.dropSelectedItem(false); });
        add("SpinJump", "Gira enquanto está no ar", mc -> { if (!mc.player.isOnGround()) mc.player.setYaw(mc.player.getYaw() + 40); });
        add("Ragdoll", "ABSURDO: câmera de boneco de pano", mc -> {
            mc.player.setYaw(R.nextFloat() * 360f - 180f);
            mc.player.setPitch(R.nextFloat() * 180f - 90f);
        });
        add("Seasick", "ABSURDO: enjoo de barco", mc -> {
            mc.player.setPitch((float) (Math.sin(t(mc) * 0.1) * 20));
            mc.player.setYaw(mc.player.getYaw() + (float) (Math.sin(t(mc) * 0.05) * 3));
        });
        add("Circle", "Anda em círculos", mc -> {
            mc.options.forwardKey.setPressed(true);
            mc.player.setYaw(mc.player.getYaw() + 4);
        }, mc -> mc.options.forwardKey.setPressed(false));
        add("Patrol", "Anda reto e vira 90° a cada 5s", mc -> {
            mc.options.forwardKey.setPressed(true);
            if (t(mc) % 100 == 0) mc.player.setYaw(mc.player.getYaw() + 90);
        }, mc -> mc.options.forwardKey.setPressed(false));
        add("Zigzag", "Anda em zigue-zague", mc -> {
            mc.options.forwardKey.setPressed(true);
            if (t(mc) % 20 == 0) mc.player.setYaw(mc.player.getYaw() + ((t(mc) / 20) % 2 == 0 ? 45 : -45));
        }, mc -> mc.options.forwardKey.setPressed(false));
        add("StrafeBot", "Alterna esquerda/direita", mc -> {
            boolean l = (t(mc) / 20) % 2 == 0;
            mc.options.leftKey.setPressed(l);
            mc.options.rightKey.setPressed(!l);
        }, mc -> { mc.options.leftKey.setPressed(false); mc.options.rightKey.setPressed(false); });
        add("Tornado", "ABSURDO: gira e sobe feito tornado", mc -> {
            mc.player.setYaw(mc.player.getYaw() + 40);
            vy(mc, 0.15);
        });
        add("Lift", "Pulo + sneak = elevador", mc -> { if (mc.options.jumpKey.isPressed() && mc.options.sneakKey.isPressed()) vy(mc, 0.5); });
        add("Skydive", "Sneak no ar = mergulho de paraquedista", mc -> {
            if (!mc.player.isOnGround() && mc.options.sneakKey.isPressed()) { vy(mc, -0.1); hscale(mc, 1.04, 0.9); }
        });
        add("Rocketeer", "ABSURDO: foguete com propulsão pra frente", mc -> {
            if (!mc.options.jumpKey.isPressed()) return;
            vy(mc, Math.min(mc.player.getVelocity().y + 0.3, 2.5));
            hscale(mc, 1.05, 1.0);
        });
    }

    // ---------- VISUAL (16) ----------
    static void visual() {
        esp("MobESP", "Brilho em mobs hostis", e -> e instanceof HostileEntity);
        esp("PlayerESP", "Brilho em jogadores", e -> e instanceof PlayerEntity);
        esp("AnimalESP", "Brilho em animais", e -> e instanceof AnimalEntity);
        esp("ItemESP", "Brilho em itens no chão", e -> e instanceof ItemEntity);
        esp("XPESP", "Brilho em orbs de XP", e -> e instanceof ExperienceOrbEntity);
        esp("AllESP", "Brilho em todos os seres vivos", e -> e instanceof LivingEntity);
        esp("VillagerESP", "Brilho em aldeões", e -> e instanceof VillagerEntity);
        esp("CreeperESP", "Brilho em creepers", e -> e instanceof CreeperEntity);
        esp("BatESP", "Brilho em morcegos", e -> e instanceof BatEntity);
        esp("SlimeESP", "Brilho em slimes", e -> e instanceof SlimeEntity);
        esp("EndermanESP", "Brilho em endermen", e -> e instanceof EndermanEntity);
        esp("SkeletonESP", "Brilho em esqueletos", e -> e instanceof AbstractSkeletonEntity);
        esp("ZombieESP", "Brilho em zumbis", e -> e instanceof ZombieEntity);
        esp("ArrowESP", "Brilho em flechas", e -> e instanceof PersistentProjectileEntity);
        add("NoRain", "Remove chuva e trovão visualmente", mc -> { mc.world.setRainGradient(0f); mc.world.setThunderGradient(0f); });
        add("AntiBlind", "Remove cegueira e escuridão visuais", mc -> {
            mc.player.removeStatusEffect(StatusEffects.BLINDNESS);
            mc.player.removeStatusEffect(StatusEffects.DARKNESS);
        });
    }

    // ---------- COMBATE (9) ----------
    static void combat() {
        add("TriggerBot", "Ataca o mob que está na mira", mc -> {
            if (mc.crosshairTarget instanceof EntityHitResult r && r.getEntity() instanceof LivingEntity && !(r.getEntity() instanceof PlayerEntity) && ready(mc))
                hit(mc, r.getEntity());
        });
        add("AutoClicker", "Segura o botão de ataque", mc -> mc.options.attackKey.setPressed(true), mc -> mc.options.attackKey.setPressed(false));
        add("AimBot", "Mira no hostil mais próximo", mc -> {
            Entity e = nearest(mc, x -> x instanceof HostileEntity, 8);
            if (e != null) face(mc, e);
        });
        add("MultiAura", "Ataca até 3 hostis de uma vez", mc -> {
            if (!ready(mc)) return;
            int n = 0;
            for (Entity e : mc.world.getEntities())
                if (e instanceof HostileEntity h && h.isAlive() && mc.player.distanceTo(h) < 3.5f) { hit(mc, h); if (++n >= 3) break; }
        });
        add("AnimalAura", "Ataca animais próximos (fazenda)", mc -> {
            if (!ready(mc)) return;
            Entity e = nearest(mc, x -> x instanceof AnimalEntity && x.isAlive(), 3.5);
            if (e != null) hit(mc, e);
        });
        add("UndeadAura", "Ataca zumbis e esqueletos", mc -> {
            if (!ready(mc)) return;
            Entity e = nearest(mc, x -> (x instanceof ZombieEntity || x instanceof AbstractSkeletonEntity) && x.isAlive(), 4.0);
            if (e != null) hit(mc, e);
        });
        add("CreeperRepel", "ABSURDO: creepers te empurram pra longe", mc -> {
            Entity e = nearest(mc, x -> x instanceof CreeperEntity, 7);
            if (e != null) push(mc, e, 0.25);
        });
        add("Retreat", "Foge do hostil mais próximo", mc -> {
            Entity e = nearest(mc, x -> x instanceof HostileEntity, 6);
            if (e != null) push(mc, e, 0.15);
        });
        add("Stalker", "ABSURDO: sempre encara o jogador mais próximo", mc -> {
            Entity e = nearest(mc, x -> x instanceof PlayerEntity, 30);
            if (e != null) face(mc, e);
        });
    }

    // ---------- UTILIDADES (14) ----------
    static void utility() {
        add("AutoRespawn", "Renasce sozinho", mc -> { if (mc.player.isDead()) mc.player.requestRespawn(); });
        add("AntiAFK", "Evita ser kickado por AFK", mc -> {
            if (t(mc) % 200 != 0) return;
            vy(mc, 0.42);
            mc.player.swingHand(Hand.MAIN_HAND);
            mc.player.setYaw(mc.player.getYaw() + 5);
        });
        add("NoFall", "Zera a distância de queda no cliente", mc -> mc.player.fallDistance = 0);
        add("Nuker", "Quebra blocos num raio de 2", mc -> {
            BlockPos c = mc.player.getBlockPos();
            for (int x = -2; x <= 2; x++) for (int y = -1; y <= 2; y++) for (int z = -2; z <= 2; z++) {
                BlockPos b = c.add(x, y, z);
                var s = mc.world.getBlockState(b);
                if (s.isAir() || s.getHardness(mc.world, b) < 0) continue;
                mc.interactionManager.updateBlockBreakingProgress(b, Direction.UP);
                return;
            }
        });
        add("Bridge", "Coloca blocos sob seus pés (segure um bloco)", mc -> {
            BlockPos below = mc.player.getBlockPos().down();
            if (!mc.world.getBlockState(below).isAir() || !(mc.player.getMainHandStack().getItem() instanceof BlockItem)) return;
            for (Direction d : Direction.values()) {
                if (d == Direction.UP) continue;
                BlockPos n = below.offset(d);
                if (mc.world.getBlockState(n).isAir()) continue;
                Direction face = d.getOpposite();
                Vec3d pos = Vec3d.ofCenter(n).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
                mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(pos, face, n, false));
                return;
            }
        });
        add("AutoSwim", "Nada rápido na água", mc -> { if (mc.player.isTouchingWater() && mc.options.forwardKey.isPressed()) mc.player.setSprinting(true); });
        add("LavaEscape", "Sobe sozinho quando cai na lava", mc -> { if (mc.player.isInLava()) vy(mc, 0.3); });
        add("Hotfoot", "ABSURDO: pegando fogo você corre mais", mc -> { if (mc.player.isOnFire() && moving(mc)) hscale(mc, 1.3, 0.8); });
        add("HealthAlert", "Avisa quando a vida está baixa", mc -> {
            if (mc.player.getHealth() < 6 && t(mc) % 40 == 0) mc.player.sendMessage(Text.literal("§cVida baixa!"), true);
        });
        add("HungerAlert", "Avisa quando a fome está alta", mc -> {
            if (mc.player.getHungerManager().getFoodLevel() < 6 && t(mc) % 40 == 0) mc.player.sendMessage(Text.literal("§6Fome!"), true);
        });
        add("CoordsPing", "Mostra suas coordenadas no chat a cada 10s", mc -> {
            if (t(mc) % 200 == 0)
                mc.player.sendMessage(Text.literal(String.format("§7XYZ: %.0f %.0f %.0f", mc.player.getX(), mc.player.getY(), mc.player.getZ())), false);
        });
        add("AutoMine", "Segura o ataque quando mira num bloco", mc ->
            mc.options.attackKey.setPressed(mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.BLOCK),
            mc -> mc.options.attackKey.setPressed(false));
        add("AutoUse", "Segura o botão de usar item", mc -> mc.options.useKey.setPressed(true), mc -> mc.options.useKey.setPressed(false));
        add("AutoBack", "Anda de costas sozinho", mc -> mc.options.backKey.setPressed(true), mc -> mc.options.backKey.setPressed(false));
    }
}
