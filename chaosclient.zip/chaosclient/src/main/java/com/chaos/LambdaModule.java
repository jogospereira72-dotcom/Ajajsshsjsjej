package com.chaos;

import net.minecraft.client.MinecraftClient;
import java.util.function.Consumer;

public class LambdaModule extends Module {
    private final Consumer<MinecraftClient> tick;
    private final Consumer<MinecraftClient> off;

    public LambdaModule(String n, String d, Consumer<MinecraftClient> tick, Consumer<MinecraftClient> off) {
        super(n, d);
        this.tick = tick;
        this.off = off;
    }

    @Override public void onTick(MinecraftClient mc) { tick.accept(mc); }

    @Override protected void onDisable(MinecraftClient mc) {
        if (off != null && mc.player != null) off.accept(mc);
    }
}
