package com.chaos;

import com.chaos.modules.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class ChaosClient implements ClientModInitializer {
    public static final List<Module> MODULES = new ArrayList<>();

    @Override
    public void onInitializeClient() {
        MODULES.add(new Flight());
        MODULES.add(new Sprint());
        MODULES.add(new Fullbright());
        MODULES.add(new KillAura());
        MODULES.add(new Rocket());
        MODULES.add(new LowGravity());
        MODULES.add(new Spinbot());
        MODULES.add(new BunnyHop());
        MODULES.add(new GodMode());
        Modules.registerAll(MODULES);

        // Anti-crash: se um módulo lançar erro, ele é desligado em vez de derrubar o jogo.
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.player == null || mc.world == null) return;
            for (Module m : MODULES) {
                if (!m.isEnabled()) continue;
                try {
                    m.onTick(mc);
                } catch (Throwable t) {
                    try { m.toggle(); } catch (Throwable ignored) {}
                    say(mc, "§c" + m.name + " desligado por erro: " + t);
                    System.err.println("[ChaosClient] erro em " + m.name);
                    t.printStackTrace();
                }
            }
        });

        // .list | .t <modulo> | .info <modulo> | .off (desliga tudo)
        ClientSendMessageEvents.ALLOW_CHAT_MESSAGE.register(msg -> {
            if (!msg.startsWith(".")) return true;
            MinecraftClient mc = MinecraftClient.getInstance();
            String[] a = msg.substring(1).trim().split("\\s+");
            try {
                switch (a[0]) {
                    case "list" -> {
                        StringBuilder sb = new StringBuilder("§7Módulos (" + MODULES.size() + "): ");
                        for (Module m : MODULES) sb.append(m.isEnabled() ? "§a" : "§f").append(m.name).append("§7, ");
                        say(mc, sb.toString());
                    }
                    case "off" -> {
                        for (Module m : MODULES) if (m.isEnabled()) m.toggle();
                        say(mc, "§cTodos desligados");
                    }
                    case "t", "info" -> {
                        Module f = a.length > 1 ? find(a[1]) : null;
                        if (f == null) say(mc, "§cMódulo não encontrado. Use .list");
                        else if (a[0].equals("info")) say(mc, "§f" + f.name + " §7- " + f.description);
                        else { f.toggle(); say(mc, f.name + (f.isEnabled() ? " §aligado" : " §cdesligado")); }
                    }
                    default -> say(mc, "Uso: .list | .t <modulo> | .info <modulo> | .off");
                }
            } catch (Throwable t) {
                say(mc, "§cErro no comando: " + t);
            }
            return false;
        });
    }

    private static Module find(String n) {
        return MODULES.stream().filter(m -> m.name.equalsIgnoreCase(n)).findFirst().orElse(null);
    }

    private static void say(MinecraftClient mc, String s) {
        if (mc.player != null) mc.player.sendMessage(Text.literal(s), false);
    }
}
