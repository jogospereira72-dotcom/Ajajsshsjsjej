package com.chaos.modules;
import com.chaos.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public class BunnyHop extends Module {
    public BunnyHop() { super("BunnyHop", "ABSURDO: vira um coelho, pula sem parar ao andar"); }
    @Override public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p.isOnGround() && mc.options.forwardKey.isPressed()) {
            Vec3d v = p.getVelocity();
            p.setVelocity(v.x, 0.42, v.z);
        }
    }
}
