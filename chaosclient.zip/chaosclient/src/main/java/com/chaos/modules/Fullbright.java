package com.chaos.modules;
import com.chaos.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
public class Fullbright extends Module {
    public Fullbright() { super("Fullbright", "Visão noturna constante"); }
    @Override public void onTick(MinecraftClient mc) {
        mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, false, false, false));
    }
    @Override protected void onDisable(MinecraftClient mc) {
        if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
    }
}
