package com.chaos.modules;
import com.chaos.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public class Spinbot extends Module {
    public Spinbot() { super("Spinbot", "ABSURDO: gira sem parar como um beyblade"); }
    @Override public void onTick(MinecraftClient mc) {
        mc.player.setYaw(mc.player.getYaw() + 30f);
    }
}
