package com.chaos.modules;
import com.chaos.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public class Flight extends Module {
    public Flight() { super("Flight", "Voo livre"); }
    @Override public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        p.getAbilities().allowFlying = true;
        p.getAbilities().flying = true;
    }
    @Override protected void onDisable(MinecraftClient mc) {
        if (mc.player != null && !mc.player.isCreative() && !mc.player.isSpectator()) {
            mc.player.getAbilities().allowFlying = false;
            mc.player.getAbilities().flying = false;
        }
    }
}
