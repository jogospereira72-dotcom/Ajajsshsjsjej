package com.chaos.modules;
import com.chaos.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public class LowGravity extends Module {
    public LowGravity() { super("LowGravity", "ABSURDO: gravidade da lua"); }
    @Override public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        Vec3d v = p.getVelocity();
        if (!p.isOnGround() && v.y < 0) p.setVelocity(v.x, v.y * 0.6, v.z);
    }
}
