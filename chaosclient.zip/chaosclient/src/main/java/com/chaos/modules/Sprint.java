package com.chaos.modules;
import com.chaos.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public class Sprint extends Module {
    public Sprint() { super("Sprint", "Corre automaticamente"); }
    @Override public void onTick(MinecraftClient mc) {
        if (mc.options.forwardKey.isPressed() && !mc.player.horizontalCollision) mc.player.setSprinting(true);
    }
}
