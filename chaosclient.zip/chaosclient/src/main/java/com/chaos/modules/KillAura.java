package com.chaos.modules;
import com.chaos.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.util.Hand;
public class KillAura extends Module {
    public KillAura() { super("KillAura", "Ataca mobs hostis por perto (use só em singleplayer/servidor seu)"); }
    @Override public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p.getAttackCooldownProgress(0f) < 1f) return;
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof HostileEntity h && h.isAlive() && p.distanceTo(h) < 4.0f) {
                mc.interactionManager.attackEntity(p, h);
                p.swingHand(Hand.MAIN_HAND);
                break;
            }
        }
    }
}
