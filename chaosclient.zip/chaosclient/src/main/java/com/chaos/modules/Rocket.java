package com.chaos.modules;
import com.chaos.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public class Rocket extends Module {
    public Rocket() { super("Rocket", "ABSURDO: segure pulo e decole como foguete"); }
    @Override public void onTick(MinecraftClient mc) {
        if (!mc.options.jumpKey.isPressed()) return;
        Vec3d v = mc.player.getVelocity();
        mc.player.setVelocity(v.x, Math.min(v.y + 0.2, 2.0), v.z);
    }
}
