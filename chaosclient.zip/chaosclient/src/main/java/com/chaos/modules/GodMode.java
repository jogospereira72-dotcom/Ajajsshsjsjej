package com.chaos.modules;

import com.chaos.Module;
import net.minecraft.client.MinecraftClient;

/** Imortalidade via comandos do servidor. Só funciona onde você tem permissão de OP (singleplayer com cheats ou servidor seu). */
public class GodMode extends Module {
    public GodMode() { super("GodMode", "Imortal via /effect (precisa de OP: singleplayer com cheats ou servidor seu)"); }

    @Override protected void onEnable(MinecraftClient mc) {
        if (mc.player == null) return;
        var n = mc.player.networkHandler;
        n.sendChatCommand("effect give @s minecraft:resistance infinite 4 true");
        n.sendChatCommand("effect give @s minecraft:regeneration infinite 4 true");
        n.sendChatCommand("effect give @s minecraft:fire_resistance infinite 0 true");
        n.sendChatCommand("effect give @s minecraft:saturation infinite 0 true");
    }

    @Override protected void onDisable(MinecraftClient mc) {
        if (mc.player == null) return;
        var n = mc.player.networkHandler;
        n.sendChatCommand("effect clear @s minecraft:resistance");
        n.sendChatCommand("effect clear @s minecraft:regeneration");
        n.sendChatCommand("effect clear @s minecraft:fire_resistance");
        n.sendChatCommand("effect clear @s minecraft:saturation");
    }
}
