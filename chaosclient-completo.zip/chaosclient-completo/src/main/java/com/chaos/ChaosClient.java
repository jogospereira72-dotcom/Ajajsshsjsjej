package com.chaos;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

/** Entrypoint mínimo e autónomo do ChaosClient. */
public final class ChaosClient implements ClientModInitializer {
    public static final List<Module> MODULES = new ArrayList<>();

    @Override
    public void onInitializeClient() {
        registerDefaults();
        ClientTickEvents.END_CLIENT_TICK.register(ChaosClient::tick);
    }

    private static void registerDefaults() {
        if (!MODULES.isEmpty()) return;
        MODULES.add(new Module("Fullbright", "Aumenta a visibilidade em locais escuros") {
            @Override protected void onEnable() {
                // Reservado para integração com o brilho da versão usada.
            }
        });
        MODULES.add(new Module("Coordinates", "Mostra coordenadas no HUD") {
            @Override protected void onEnable() {}
        });
    }

    private static void tick(MinecraftClient client) {
        // Ponto de extensão para módulos do cliente.
    }
}
