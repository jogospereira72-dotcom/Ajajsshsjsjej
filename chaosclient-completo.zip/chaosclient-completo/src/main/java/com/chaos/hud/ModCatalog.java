package com.chaos.hud;

import com.chaos.ChaosClient;

import java.util.*;

/**
 * Catálogo dinâmico de mods exibidos na aba Mods.
 *
 * <ul>
 *   <li>Lê {@link ChaosClient#MODULES} e cria um adaptador para cada {@code com.chaos.Module};
 *       módulos adicionados no futuro aparecem sozinhos.</li>
 *   <li>Aceita mods nativos do HUD via {@link #register(Mod)}.</li>
 *   <li>Categorias: use {@link #setCategory(String, String)} para classificar um módulo
 *       pelo nome; sem regra, vale uma heurística simples (ESP/Fullbright = Visual,
 *       descrição começando com "ABSURDO" = Absurdo, KillAura/GodMode = Combate, resto = Geral).</li>
 * </ul>
 */
public final class ModCatalog {

    private static final ModCatalog INSTANCE = new ModCatalog();

    public static ModCatalog get() {
        return INSTANCE;
    }

    private final List<Mod> natives = new ArrayList<>();
    private final List<Mod> all = new ArrayList<>();
    private final Map<String, String> categoryRules = new HashMap<>();
    private final Map<String, Mod> byId = new HashMap<>();
    private List<String> categories = List.of();
    private int knownChaos = -1;
    private int version;

    // cache da lista filtrada
    private List<Mod> view = List.of();
    private String viewCat = null;
    private int viewVersion = -1;

    private ModCatalog() {}

    /** Registra um mod nativo (aparece junto com os demais). */
    public void register(Mod mod) {
        natives.add(mod);
        knownChaos = -1; // força reconstrução
    }

    /** Define a categoria de um módulo do ChaosClient pelo nome. */
    public void setCategory(String moduleName, String category) {
        categoryRules.put(moduleName, category);
        knownChaos = -1;
    }

    /** Reconstrói a lista se o número de módulos mudou. Barato: só compara um inteiro. */
    public void refresh() {
        int n = ChaosClient.MODULES.size();
        if (n == knownChaos) return;
        knownChaos = n;
        all.clear();
        byId.clear();
        for (com.chaos.Module m : ChaosClient.MODULES) all.add(new ChaosModuleMod(m, categorize(m)));
        all.addAll(natives);
        all.sort(Comparator.comparing((Mod m) -> m.category).thenComparing(m -> m.name, String.CASE_INSENSITIVE_ORDER));
        TreeSet<String> cats = new TreeSet<>();
        for (Mod m : all) {
            byId.put(m.id, m);
            cats.add(m.category);
        }
        categories = new ArrayList<>(cats);
        version++;
    }

    private String categorize(com.chaos.Module m) {
        String rule = categoryRules.get(m.name);
        if (rule != null) return rule;
        String n = m.name, d = m.description == null ? "" : m.description;
        if (n.endsWith("ESP") || n.equals("Fullbright")) return "Visual";
        if (n.equals("KillAura") || n.equals("GodMode")) return "Combate";
        if (d.startsWith("ABSURDO")) return "Absurdo";
        return "Geral";
    }

    public int size() {
        return all.size();
    }

    public List<String> categories() {
        return categories;
    }

    /** Lista filtrada por categoria ("Todos" = tudo). Resultado em cache. */
    public List<Mod> view(String category) {
        if (category.equals(viewCat) && viewVersion == version) return view;
        List<Mod> out = new ArrayList<>();
        for (Mod m : all) if (category.equals("Todos") || m.category.equals(category)) out.add(m);
        view = out;
        viewCat = category;
        viewVersion = version;
        return view;
    }

    public int enabledCount() {
        int c = 0;
        for (Mod m : all) if (m.isEnabled()) c++;
        return c;
    }

    /** Nomes dos mods ligados (maiores primeiro), limitado a {@code max} linhas. */
    public List<String> enabledNames(int max) {
        refresh();
        List<String> out = new ArrayList<>();
        for (Mod m : all) if (m.isEnabled()) out.add(m.name);
        out.sort(Comparator.<String>comparingInt(String::length).reversed().thenComparing(Comparator.naturalOrder()));
        if (out.size() > max) {
            int extra = out.size() - max;
            out = new ArrayList<>(out.subList(0, max));
            out.add("+" + extra + " ...");
        }
        return out;
    }

    public void disableAll() {
        for (Mod m : all) if (m.isEnabled()) m.setEnabled(false);
        persist();
    }

    // --------------------------------------------------------------- persistência

    /** Grava na config o conjunto de mods ligados. */
    public void persist() {
        HudConfig c = HudConfig.get();
        Set<String> now = new TreeSet<>();
        for (Mod m : all) if (m.isEnabled()) now.add(m.id);
        if (!now.equals(c.enabledMods)) {
            c.enabledMods = now;
            c.markDirty();
        }
    }

    /** Religa os mods salvos. Módulos do ChaosClient só são religados se a opção estiver ativa. */
    public void restore(boolean includeChaosModules) {
        refresh();
        for (String id : new ArrayList<>(HudConfig.get().enabledMods)) {
            Mod m = byId.get(id);
            if (m == null || m.isEnabled()) continue;
            if (m.persistAlways() || includeChaosModules) {
                try {
                    m.setEnabled(true);
                } catch (Throwable t) {
                    System.err.println("[ChaosHud] não foi possível restaurar " + m.name + ": " + t);
                }
            }
        }
    }

    // ------------------------------------------------------------------ adaptador

    /** Faz um {@code com.chaos.Module} se comportar como {@link Mod}. */
    private static final class ChaosModuleMod extends Mod {
        private final com.chaos.Module module;

        ChaosModuleMod(com.chaos.Module module, String category) {
            super("chaos:" + module.name, module.name, module.description, category);
            this.module = module;
        }

        @Override
        public boolean isEnabled() {
            return module.isEnabled();
        }

        @Override
        public void setEnabled(boolean enabled) {
            if (enabled == module.isEnabled()) return;
            try {
                module.toggle();
            } catch (Throwable t) {
                System.err.println("[ChaosHud] erro ao alternar " + module.name + ": " + t);
            }
        }
    }
}
