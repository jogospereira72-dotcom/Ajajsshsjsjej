package com.chaos.hud;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Configuração do HUD, salva em {@code .minecraft/config/chaosclient-hud.json}.
 *
 * <p>Salvamento automático: qualquer alteração chama {@link #markDirty()}; o arquivo é
 * gravado ~0,8 s depois da última alteração (debounce, para não gravar a cada frame
 * enquanto você arrasta algo) e sempre ao fechar o menu / o jogo. A escrita em disco
 * acontece numa thread separada para não causar engasgos.</p>
 */
public final class HudConfig {

    // ------------------------------------------------------------ estruturas

    /** Estado da janela principal. Posição normalizada (0..1) para sobreviver a mudanças de resolução. */
    public static final class WindowState {
        public float nx = 0.5f, ny = 0.5f;
        public float w = 380f, h = 270f;
        public int tab = 0;
    }

    /** Estado de um widget do HUD. */
    public static final class WidgetState {
        public boolean enabled = true;
        public float nx = 0.02f, ny = 0.02f;
        public float scale = 1f;

        public WidgetState() {}

        public WidgetState(boolean enabled, float nx, float ny) {
            this.enabled = enabled;
            this.nx = nx;
            this.ny = ny;
        }
    }

    // ---------------------------------------------------------------- campos

    public int version = 1;

    // Aparência do menu
    public float menuScale = 1f;
    public float menuOpacity = 0.78f;
    public float accentHue = 0.52f;
    public int accent = 0x37D6E8;
    public int modOnColor = 0x5CFFA8;

    // Aparência dos widgets
    public boolean hudBackground = true;
    public float hudBgOpacity = 0.45f;
    public int hudTextColor = 0xFFFFFF;

    // Desempenho
    public boolean animations = true;
    public float animSpeed = 1f;
    public boolean hudShadows = true;
    public boolean lowGlass = false;
    public int hudUpdateMs = 250;
    public boolean perfParticles = true;
    public boolean perfEntities = true;
    public boolean perfFpsCap = false;
    public int perfFpsCapValue = 60;
    public boolean clearCachesOnClose = true;
    public boolean gcOnClose = false;

    // Módulos
    public boolean restoreModsOnJoin = false;
    public Set<String> enabledMods = new TreeSet<>();
    public Map<String, Float> modSettings = new HashMap<>();

    // Layout
    public WindowState window = new WindowState();
    public Map<String, WidgetState> widgets = new LinkedHashMap<>();

    private transient boolean dirty;
    private transient long dirtyAt;

    // -------------------------------------------------------- singleton / IO

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final ExecutorService IO = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "chaosclient-hud-io");
        t.setDaemon(true);
        return t;
    });
    private static HudConfig instance;

    public static HudConfig get() {
        if (instance == null) load();
        return instance;
    }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("chaosclient-hud.json");
    }

    /** Carrega do disco (ou cria padrão). Arquivo corrompido vira {@code .bak} e é recriado. */
    public static void load() {
        HudConfig cfg = null;
        Path p = path();
        if (Files.exists(p)) {
            try {
                cfg = GSON.fromJson(Files.readString(p, StandardCharsets.UTF_8), HudConfig.class);
            } catch (Exception e) {
                System.err.println("[ChaosHud] config inválida, usando padrão: " + e);
                try { Files.move(p, p.resolveSibling("chaosclient-hud.json.bak"), StandardCopyOption.REPLACE_EXISTING); }
                catch (IOException ignored) {}
            }
        }
        if (cfg == null) cfg = new HudConfig();
        cfg.sanitize();
        instance = cfg;
    }

    /** Corrige nulos e limita valores (protege contra edição manual errada do JSON). */
    private void sanitize() {
        if (window == null) window = new WindowState();
        if (widgets == null) widgets = new LinkedHashMap<>();
        if (enabledMods == null) enabledMods = new TreeSet<>();
        if (modSettings == null) modSettings = new HashMap<>();
        menuScale = clamp(menuScale, 0.7f, 1.6f);
        menuOpacity = clamp(menuOpacity, 0.3f, 1f);
        hudBgOpacity = clamp(hudBgOpacity, 0.1f, 1f);
        animSpeed = clamp(animSpeed, 0.5f, 3f);
        hudUpdateMs = Math.max(50, Math.min(1000, hudUpdateMs));
        perfFpsCapValue = Math.max(30, Math.min(240, perfFpsCapValue));
        window.nx = clamp(window.nx, 0f, 1f);
        window.ny = clamp(window.ny, 0f, 1f);
        window.tab = Math.max(0, Math.min(3, window.tab));
        for (WidgetState s : widgets.values()) {
            s.nx = clamp(s.nx, 0f, 1f);
            s.ny = clamp(s.ny, 0f, 1f);
            s.scale = clamp(s.scale, 0.5f, 3f);
        }
    }

    private static float clamp(float v, float lo, float hi) {
        return Float.isNaN(v) ? lo : Math.max(lo, Math.min(hi, v));
    }

    // ------------------------------------------------------------- salvamento

    /** Avisa que algo mudou; a gravação ocorre após 0,8 s sem novas alterações. */
    public void markDirty() {
        dirty = true;
        dirtyAt = System.currentTimeMillis();
    }

    /** Chamado todo tick: grava se houve alteração "assentada". */
    public void tickSave() {
        if (dirty && System.currentTimeMillis() - dirtyAt > 800) saveAsync();
    }

    /** Grava de forma assíncrona. */
    public void saveAsync() {
        dirty = false;
        final String json = GSON.toJson(this); // serializa no thread do jogo (rápido)
        IO.execute(() -> write(json));
    }

    /** Grava de forma síncrona se houver pendência (fechar menu / sair do jogo). */
    public void flushNow() {
        if (!dirty) return;
        dirty = false;
        write(GSON.toJson(this));
    }

    private static void write(String json) {
        Path p = path();
        Path tmp = p.resolveSibling("chaosclient-hud.json.tmp");
        try {
            Files.createDirectories(p.getParent());
            Files.writeString(tmp, json, StandardCharsets.UTF_8);
            try {
                Files.move(tmp, p, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(tmp, p, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException e) {
            System.err.println("[ChaosHud] falha ao salvar config: " + e);
        }
    }

    // ---------------------------------------------------------------- resets

    public void resetAppearance() {
        HudConfig d = new HudConfig();
        menuScale = d.menuScale;
        menuOpacity = d.menuOpacity;
        accentHue = d.accentHue;
        accent = d.accent;
        modOnColor = d.modOnColor;
        markDirty();
    }
}
