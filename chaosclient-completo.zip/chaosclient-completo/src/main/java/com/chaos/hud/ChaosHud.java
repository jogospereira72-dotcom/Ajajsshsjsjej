package com.chaos.hud;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/**
 * Entrypoint do HUD Client (segundo entrypoint "client" no fabric.mod.json, então
 * {@code ChaosClient} não precisa ser alterado).
 *
 * <p>O atalho X é lido direto do GLFW (sem KeyBinding): assim o código não depende de
 * assinaturas de input que mudam entre versões do Minecraft.</p>
 */
public final class ChaosHud implements ClientModInitializer {

    private boolean xWasDown;
    private boolean restored;
    private int ticks;

    @Override
    public void onInitializeClient() {
        HudConfig.load();

        // Aqui você registra novos mods nativos:
        ModCatalog.get().register(new FpsBoostMod());

        // HUD normal (menu fechado). Fica antes do chat para não cobrir mensagens.
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.of("chaosclient", "hud_widgets"),
                (graphics, tickCounter) -> WidgetRegistry.renderInGame(graphics));

        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);

        // Ao sair do jogo: devolve as opções alteradas e grava a config.
        ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> {
            Perf.restoreAll(mc);
            HudConfig.get().flushNow();
        });
    }

    private void onTick(MinecraftClient mc) {
        if (mc.getWindow() == null) return;
        HudConfig cfg = HudConfig.get();

        // ---- tecla X abre o menu (só no jogo, sem outra tela aberta)
        boolean xDown = GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_X) == GLFW.GLFW_PRESS;
        if (xDown && !xWasDown && mc.currentScreen == null && mc.player != null) {
            mc.setScreen(new HudScreen());
        }
        xWasDown = xDown;

        // ---- restaurar mods ao entrar no mundo
        boolean inWorld = mc.player != null && mc.world != null;
        if (!inWorld) {
            restored = false;
        } else if (!restored) {
            restored = true;
            ModCatalog.get().restore(cfg.restoreModsOnJoin);
        }

        ticks++;
        // ---- mantém a config em dia com módulos ligados por comandos de chat (.t flight etc.)
        if (inWorld && restored && ticks % 40 == 0) {
            ModCatalog.get().refresh();
            ModCatalog.get().persist();
        }
        if (ticks % 10 == 0) Perf.tick(mc);

        cfg.tickSave();
    }
}
