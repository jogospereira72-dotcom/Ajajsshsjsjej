package com.chaos.hud;

import net.minecraft.client.MinecraftClient;

/**
 * Mod nativo de exemplo: "FPS Boost".
 *
 * <p>Quando ligado, reduz partículas e a distância de renderização de entidades enquanto você
 * joga (as opções originais voltam ao desligar). Serve também de modelo para criar novos mods:
 * estenda {@link Mod}, declare settings com {@code add(...)} e registre em
 * {@link ChaosHud#onInitializeClient()}.</p>
 */
public final class FpsBoostMod extends Mod {

    public static FpsBoostMod INSTANCE;

    private final FloatSetting entityScale =
            add(new FloatSetting("entityScale", "Distância das entidades", 0.5f, 2.0f, 0.25f, 0.75f));
    private final BoolSetting particles =
            add(new BoolSetting("particles", "Reduzir partículas", true));

    private boolean on;

    public FpsBoostMod() {
        super("native:fpsboost", "FPS Boost",
                "Reduz partículas e distância de entidades para ganhar FPS", "Desempenho");
        INSTANCE = this;
    }

    @Override
    public boolean isEnabled() {
        return on;
    }

    @Override
    public void setEnabled(boolean enabled) {
        on = enabled;
        MinecraftClient mc = MinecraftClient.getInstance();
        Perf.update(mc, mc.currentScreen instanceof HudScreen);
    }

    @Override
    public boolean persistAlways() {
        return true;
    }

    public double entityScale() {
        return entityScale.get();
    }

    public boolean reduceParticles() {
        return particles.get();
    }

    /** Assinatura das settings atuais; muda quando o usuário mexe em algum slider/toggle. */
    int signature() {
        return on ? java.util.Objects.hash(entityScale.get(), particles.get()) : 0;
    }
}
