package com.chaos.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.joml.Matrix3x2fStack;
import org.lwjgl.glfw.GLFW;

import java.util.*;

/**
 * Menu principal do ChaosClient (abre/fecha com X ou ESC).
 *
 * <p>Arquitetura: UI em "modo imediato". Cada frame a tela lê o estado do mouse, desenha os
 * controles e já processa os cliques no mesmo passo. Por isso não há objetos de widget de UI
 * (nada para alocar/limpar), só funções como {@link #toggleRow}, {@link #slider} etc.
 * O mouse e a tecla X são lidos direto do GLFW; assim só {@code render} e {@code shouldPause}
 * dependem de assinaturas do Minecraft (e {@code mouseScrolled} para a rodinha).</p>
 *
 * <p>Sistema de coordenadas: a janela é desenhada em "coordenadas locais" (0,0 = canto
 * superior esquerdo da janela) com uma matriz que aplica posição, escala do menu e a animação
 * de abertura; o mouse é convertido para o mesmo espaço ({@link #lx}, {@link #ly}).</p>
 */
public final class HudScreen extends Screen {

    /** Se o recorte da lista aparecer errado na sua versão, ponha false: só linhas totalmente visíveis serão desenhadas. */
    private static final boolean USE_SCISSOR = true;

    private static final int PAD = 10, TITLE_H = 26, TAB_H = 22, MIN_W = 320, MIN_H = 220, MAX_W = 640, MAX_H = 460;
    private static final float SNAP = 6f;
    private static final int TXT = 0xE6E9F2, DIM = 0x8A90A0;
    private static final String[] TABS = {"Mods", "HUD", "Aparência", "Desempenho"};
    private static final int[] SWATCHES = {0x37D6E8, 0x5CFFA8, 0xFF5C8A, 0xB06BFF, 0xFFB454, 0x6EA8FF, 0xFF6B4A, 0xFFFFFF};

    private enum Drag { NONE, WIN_MOVE, WIN_RESIZE, WGT_MOVE, WGT_SIZE, SLIDER, SCROLLBAR }

    private final MinecraftClient mc = MinecraftClient.getInstance();
    private final HudConfig cfg = HudConfig.get();
    private TextRenderer tr;
    private DrawContext g;

    // animação de abrir/fechar
    private float open;
    private boolean closing, finished, started;
    private long lastNs = System.nanoTime();
    private float dt;
    private final Map<String, Float> anim = new HashMap<>();

    // entrada
    private int mx, my;
    private boolean down, pressed, released, prevDown, xWasDown = true; // xWasDown=true: o X que abriu o menu não fecha
    private float lx, ly;          // mouse em coordenadas locais da janela
    private boolean viewHover;

    // arrastes
    private Drag drag = Drag.NONE;
    private float gx, gy, anchorX, anchorY;
    private HudWidget dragWidget;
    private String dragId;

    // geometria da janela (pixels de tela)
    private float wx, wy, wW, wH, T;

    // conteúdo
    private final float[] scrollCur = new float[4], scrollTgt = new float[4];
    private float contentH, tabX = -1f, curY, ind, cwFull;
    private float vx0, vy0, vx1, vy1;
    private boolean changed;
    private String catFilter = "Todos";
    private final Set<String> expanded = new HashSet<>();

    public HudScreen() {
        super(Text.literal("ChaosClient"));
        if (!cfg.animations) open = 1f;
    }

    // ================================================================= ciclo de vida

    @Override
    protected void init() {
        if (!started) {
            started = true;
            Perf.update(mc, true); // menu aberto: aplica reduções de partículas/entidades/FPS
        }
    }

    @Override
    public boolean shouldPause() {
        return false; // o jogo continua rodando atrás do menu
    }

    /** ESC e o botão fechar passam por aqui: inicia a animação de saída. */
    @Override
    public void close() {
        if (closing) return;
        closing = true;
        if (!cfg.animations) open = 0f;
    }

    @Override
    public void removed() {
        cfg.flushNow();
        Perf.update(mc, false);
        Perf.onMenuClosed(cfg);
        super.removed();
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        if (viewHover) {
            scrollTgt[cfg.window.tab] -= (float) vertical * 30f;
            return true;
        }
        return false;
    }

    // ===================================================================== render

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        g = ctx;
        tr = mc.textRenderer;
        mx = mouseX;
        my = mouseY;

        long now = System.nanoTime();
        dt = Math.min(0.1f, (now - lastNs) / 1e9f);
        lastNs = now;
        Perf.frame();

        pollInput();
        stepOpen();
        if (finished) return;

        float e = ease(open);
        Gfx.alpha = e;
        changed = false;

        processWindowDrag();
        layoutWindow(e);

        g.fill(0, 0, width, height, Gfx.rgba(0x000000, 0.38f)); // escurece o jogo atrás
        widgetPass();
        drawWindow();

        Gfx.textC(g, tr, "X / ESC fecha  |  arraste janelas e widgets", width / 2f, height - 14, DIM, 0.8f, true);
        Gfx.alpha = 1f;
        if (changed) cfg.markDirty();
    }

    // ---------------------------------------------------------------- entrada / anim

    private void pollInput() {
        long h = mc.getWindow().getHandle();
        down = GLFW.glfwGetMouseButton(h, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        pressed = down && !prevDown;
        released = !down && prevDown;
        prevDown = down;
        if (closing) pressed = false;

        boolean xDown = GLFW.glfwGetKey(h, GLFW.GLFW_KEY_X) == GLFW.GLFW_PRESS;
        if (xDown && !xWasDown) close();
        xWasDown = xDown;

        if (released && drag != Drag.NONE) {
            drag = Drag.NONE;
            dragWidget = null;
            dragId = null;
            cfg.markDirty();
        }
    }

    private void stepOpen() {
        if (!cfg.animations) {
            open = closing ? 0f : 1f;
        } else {
            float step = dt * Math.max(0.25f, cfg.animSpeed) / 0.20f;
            open = closing ? Math.max(0f, open - step) : Math.min(1f, open + step);
        }
        if (closing && open <= 0f && !finished) {
            finished = true;
            mc.execute(() -> mc.setScreen(null));
        }
    }

    private static float ease(float t) {
        float f = 1f - t;
        return 1f - f * f * f;
    }

    /** Suaviza um valor por chave (hover, knob dos switches, indicador de aba). */
    private float smooth(String key, float target) {
        Float cur = anim.get(key);
        if (cur == null || !cfg.animations) {
            anim.put(key, target);
            return target;
        }
        float v = cur + (target - cur) * (1f - (float) Math.exp(-16f * dt * cfg.animSpeed));
        anim.put(key, v);
        return v;
    }

    // ------------------------------------------------------------ janela: geometria

    private void processWindowDrag() {
        HudConfig.WindowState ws = cfg.window;
        float S = cfg.menuScale;
        if (drag == Drag.WIN_MOVE && down) {
            float nwx = mx - gx, nwy = my - gy;
            ws.nx = width - wW <= 1 ? 0f : clamp(nwx / (width - wW), 0f, 1f);
            ws.ny = height - wH <= 1 ? 0f : clamp(nwy / (height - wH), 0f, 1f);
            changed = true;
        } else if (drag == Drag.WIN_RESIZE && down) {
            ws.w = clamp((mx - anchorX) / S, MIN_W, Math.max(MIN_W, Math.min(MAX_W, (width - anchorX) / S)));
            ws.h = clamp((my - anchorY) / S, MIN_H, Math.max(MIN_H, Math.min(MAX_H, (height - anchorY) / S)));
            float nW = ws.w * S, nH = ws.h * S;
            ws.nx = width - nW <= 1 ? 0f : clamp(anchorX / (width - nW), 0f, 1f); // canto sup. esq. fica parado
            ws.ny = height - nH <= 1 ? 0f : clamp(anchorY / (height - nH), 0f, 1f);
            changed = true;
        }
    }

    private void layoutWindow(float e) {
        HudConfig.WindowState ws = cfg.window;
        float S = cfg.menuScale;
        ws.w = clamp(ws.w, MIN_W, Math.max(MIN_W, Math.min(MAX_W, width / S - 4)));
        ws.h = clamp(ws.h, MIN_H, Math.max(MIN_H, Math.min(MAX_H, height / S - 4)));
        wW = ws.w * S;
        wH = ws.h * S;
        wx = ws.nx * Math.max(0, width - wW);
        wy = ws.ny * Math.max(0, height - wH);
        float a = cfg.animations ? 0.92f + 0.08f * e : 1f;
        T = S * a;
        float cx = wx + wW / 2f, cy = wy + wH / 2f;
        lx = (mx - cx) / T + ws.w / 2f;
        ly = (my - cy) / T + ws.h / 2f;
    }

    private boolean overWindow() {
        return lx >= 0 && lx < cfg.window.w && ly >= 0 && ly < cfg.window.h;
    }

    // ------------------------------------------------------------------- widgets

    /** Widgets em modo edição: arrastar move, o quadrado do canto redimensiona. */
    private void widgetPass() {
        List<HudWidget> ws = WidgetRegistry.all();
        boolean overWin = overWindow();
        for (HudWidget w : ws) w.refresh(tr, false);

        if (pressed && drag == Drag.NONE && !overWin) {
            for (int i = ws.size() - 1; i >= 0; i--) {
                HudWidget w = ws.get(i);
                if (!w.state().enabled) continue;
                if (w.hitHandle(mx, my, width, height)) {
                    drag = Drag.WGT_SIZE;
                    dragWidget = w;
                    break;
                }
                if (w.hit(mx, my, width, height)) {
                    drag = Drag.WGT_MOVE;
                    dragWidget = w;
                    float[] r = w.rect(width, height);
                    gx = mx - r[0];
                    gy = my - r[1];
                    break;
                }
            }
        }

        if (down && dragWidget != null) {
            if (drag == Drag.WGT_MOVE) {
                float[] r = dragWidget.rect(width, height);
                float px = mx - gx, py = my - gy;
                float[] xs = {0, (width - r[2]) / 2f, width - r[2]};
                float[] ys = {0, (height - r[3]) / 2f, height - r[3]};
                for (float c : xs) if (Math.abs(px - c) < SNAP) px = c;   // ímã nas bordas e no centro
                for (float c : ys) if (Math.abs(py - c) < SNAP) py = c;
                dragWidget.moveTo(px, py, width, height);
                changed = true;
            } else if (drag == Drag.WGT_SIZE) {
                dragWidget.resizeTo(mx, my, width, height);
                changed = true;
            }
        }

        HudWidget hov = null;
        if (!overWin && drag == Drag.NONE) {
            for (int i = ws.size() - 1; i >= 0; i--) {
                HudWidget w = ws.get(i);
                if (w.state().enabled && w.hit(mx, my, width, height)) { hov = w; break; }
            }
        }
        for (HudWidget w : ws) {
            if (w.state().enabled) w.draw(g, tr, width, height, true, w == hov || w == dragWidget);
        }
    }

    // -------------------------------------------------------------------- janela

    private void drawWindow() {
        HudConfig.WindowState ws = cfg.window;
        Matrix3x2fStack m = g.getMatrices();
        float cx = wx + wW / 2f, cy = wy + wH / 2f;
        m.pushMatrix();
        m.translate(cx, cy);
        m.scale(T, T);
        m.translate(-ws.w / 2f, -ws.h / 2f);
        try {
            drawWindowContents(ws.w, ws.h);
        } finally {
            m.popMatrix();
        }
    }

    private void drawWindowContents(float lw, float lh) {
        HudConfig.WindowState ws = cfg.window;
        int accent = cfg.accent;
        boolean inWin = overWindow();

        Gfx.glass(g, 0, 0, lw, lh, 8, cfg.menuOpacity, cfg);

        // --- barra de título
        String logo = "§lCHAOS";
        Gfx.text(g, tr, logo, PAD, 9, accent, 1f, false);
        Gfx.text(g, tr, "CLIENT", PAD + tr.getWidth(logo) + 4, 9, TXT, 0.9f, false);
        String fps = Perf.fps() + " FPS";
        Gfx.text(g, tr, fps, lw - PAD - 24 - tr.getWidth(fps), 9, DIM, 1f, false);

        float cbx = lw - PAD - 14;
        boolean hc = inWin && lx >= cbx && lx < cbx + 14 && ly >= 6 && ly < 20;
        float hv = smooth("close", hc ? 1f : 0f);
        Gfx.roundRect(g, cbx, 6, 14, 14, 3, Gfx.rgba(0xFF5C6C, 0.15f + 0.45f * hv));
        Gfx.textC(g, tr, "x", cbx + 7, 9, 0xFFFFFF, 1f, false);
        if (hc && pressed && drag == Drag.NONE) close();

        Gfx.fill(g, PAD, TITLE_H, lw - 2 * PAD, 1, Gfx.rgba(0xFFFFFF, 0.10f));

        // arrastar janela pelo título / redimensionar pelo canto
        if (pressed && drag == Drag.NONE && inWin && !hc) {
            if (ly < TITLE_H) {
                drag = Drag.WIN_MOVE;
                gx = mx - wx;
                gy = my - wy;
            } else if (lx > lw - 14 && ly > lh - 14) {
                drag = Drag.WIN_RESIZE;
                anchorX = wx;
                anchorY = wy;
            }
        }

        // --- abas
        float tabW = (lw - 2 * PAD) / TABS.length;
        float tabY = TITLE_H + 3;
        for (int i = 0; i < TABS.length; i++) {
            float x = PAD + i * tabW;
            boolean hov = inWin && lx >= x && lx < x + tabW && ly >= tabY && ly < tabY + TAB_H;
            float h = smooth("tab" + i, hov ? 1f : 0f);
            boolean act = ws.tab == i;
            Gfx.textC(g, tr, TABS[i], x + tabW / 2, tabY + 7, act ? 0xFFFFFF : Gfx.lerp(DIM, 0xFFFFFF, h), 1f, false);
            if (hov && pressed && drag == Drag.NONE) {
                ws.tab = i;
                changed = true;
            }
        }
        float targetX = PAD + ws.tab * tabW;
        tabX = tabX < 0 ? targetX : (cfg.animations ? tabX + (targetX - tabX) * (1f - (float) Math.exp(-18f * dt * cfg.animSpeed)) : targetX);
        Gfx.roundRect(g, tabX + 8, tabY + TAB_H - 2, tabW - 16, 2, 1, Gfx.rgba(accent, 1f));

        // --- área de conteúdo com scroll
        vx0 = PAD;
        vx1 = lw - PAD;
        vy0 = TITLE_H + TAB_H + 8;
        vy1 = lh - 12;
        float vh = vy1 - vy0;
        cwFull = vx1 - vx0 - 8; // 8px reservados à barra de rolagem
        viewHover = inWin && lx >= vx0 && lx < vx1 && ly >= vy0 && ly < vy1;

        int tab = ws.tab;
        float maxScroll = Math.max(0f, contentH - vh);
        scrollTgt[tab] = clamp(scrollTgt[tab], 0f, maxScroll);
        scrollCur[tab] = cfg.animations
                ? scrollCur[tab] + (scrollTgt[tab] - scrollCur[tab]) * (1f - (float) Math.exp(-20f * dt))
                : scrollTgt[tab];
        scrollCur[tab] = clamp(scrollCur[tab], 0f, maxScroll);

        curY = vy0 - scrollCur[tab];
        ind = 0;
        if (USE_SCISSOR) g.enableScissor(Math.round(vx0), Math.round(vy0), Math.round(vx1), Math.round(vy1));
        try {
            switch (tab) {
                case 0 -> modsTab();
                case 1 -> hudTab();
                case 2 -> appearanceTab();
                default -> perfTab();
            }
        } finally {
            if (USE_SCISSOR) g.disableScissor();
        }
        contentH = curY + scrollCur[tab] - vy0;

        // --- barra de rolagem
        if (contentH > vh + 1) {
            float trackX = vx1 - 4;
            Gfx.roundRect(g, trackX, vy0, 3, vh, 1, Gfx.rgba(0xFFFFFF, 0.06f));
            float thumbH = Math.max(18f, vh * vh / contentH);
            float p = maxScroll <= 0 ? 0 : scrollCur[tab] / maxScroll;
            float thumbY = vy0 + p * (vh - thumbH);
            boolean over = inWin && lx >= vx1 - 9 && lx < vx1 && ly >= vy0 && ly < vy1;
            Gfx.roundRect(g, trackX, thumbY, 3, thumbH, 1, Gfx.rgba(accent, drag == Drag.SCROLLBAR || over ? 0.9f : 0.5f));
            if (pressed && drag == Drag.NONE && over) {
                drag = Drag.SCROLLBAR;
                gy = ly - thumbY;
            }
            if (drag == Drag.SCROLLBAR && down) {
                float np = (ly - gy - vy0) / Math.max(1f, vh - thumbH);
                scrollTgt[tab] = scrollCur[tab] = clamp(np, 0f, 1f) * maxScroll;
            }
        }

        // --- alça de redimensionar
        boolean gripHot = inWin && lx > lw - 14 && ly > lh - 14;
        int gc = Gfx.rgba(0xFFFFFF, gripHot || drag == Drag.WIN_RESIZE ? 0.7f : 0.25f);
        int gxx = Math.round(lw - 9), gyy = Math.round(lh - 9);
        g.fill(gxx + 5, gyy + 5, gxx + 7, gyy + 7, gc);
        g.fill(gxx + 1, gyy + 5, gxx + 3, gyy + 7, gc);
        g.fill(gxx + 5, gyy + 1, gxx + 7, gyy + 3, gc);
    }

    // =================================================================== abas

    private void modsTab() {
        ModCatalog cat = ModCatalog.get();
        cat.refresh();
        section("Módulos (" + cat.enabledCount() + " ativos / " + cat.size() + ")");
        cfg.restoreModsOnJoin = toggleRow("restore", "Restaurar módulos ao entrar no mundo",
                "Religa os módulos que estavam ligados quando você entra", cfg.restoreModsOnJoin, null);
        if (button("offall", "Desligar todos")) cat.disableAll();

        List<String> cats = new ArrayList<>();
        cats.add("Todos");
        cats.addAll(cat.categories());
        if (!cats.contains(catFilter)) catFilter = "Todos";
        catFilter = chips(cats, catFilter);
        curY += 4;

        for (Mod mod : cat.view(catFilter)) {
            boolean has = !mod.settings().isEmpty();
            boolean cur = mod.isEnabled();
            boolean nv = toggleRow("m:" + mod.id, mod.name, mod.description, cur, has ? mod.id : null);
            if (nv != cur) {
                mod.setEnabled(nv);
                cat.persist();
            }
            if (has && expanded.contains(mod.id)) {
                ind = 14;
                for (Mod.Setting s : mod.settings()) {
                    if (s instanceof Mod.BoolSetting b) {
                        boolean v = toggleRow("s:" + mod.id + s.key, s.label, null, b.get(), null);
                        if (v != b.get()) b.set(v);
                    } else if (s instanceof Mod.FloatSetting f) {
                        float v = slider("s:" + mod.id + s.key, f.label, f.get(), f.min, f.max, f.step, "%.2f");
                        if (v != f.get()) f.set(v);
                    }
                }
                ind = 0;
            }
        }
    }

    private void hudTab() {
        note("Arraste os widgets na tela para movê-los (ímã nas bordas). O quadrado no canto inferior direito redimensiona.");
        section("Widgets");
        for (HudWidget w : WidgetRegistry.all()) {
            HudConfig.WidgetState st = w.state();
            st.enabled = toggleRow("w:" + w.id, w.name, null, st.enabled, null);
            if (st.enabled) {
                ind = 14;
                st.scale = slider("ws:" + w.id, "Escala", st.scale, 0.5f, 3f, 0.05f, "%.2fx");
                ind = 0;
            }
        }
        section("Estilo dos widgets");
        cfg.hudBackground = toggleRow("hbg", "Fundo nos widgets", null, cfg.hudBackground, null);
        if (cfg.hudBackground) {
            cfg.hudBgOpacity = slider("hop", "Transparência do fundo", cfg.hudBgOpacity, 0.1f, 1f, 0.05f, "%.2f");
        }
        cfg.hudTextColor = colorRow("htc", "Cor do texto", cfg.hudTextColor);
        if (button("rstw", "Resetar posições e escalas")) WidgetRegistry.resetAll();
    }

    private void appearanceTab() {
        section("Menu");
        cfg.menuScale = slider("scale", "Escala do menu", cfg.menuScale, 0.7f, 1.6f, 0.05f, "%.2fx");
        cfg.menuOpacity = slider("opac", "Transparência do menu", cfg.menuOpacity, 0.3f, 1f, 0.02f, "%.2f");
        section("Cores");
        float nh = slider("hue", "Matiz do destaque", cfg.accentHue, 0f, 1f, 0.01f, "%.2f");
        if (nh != cfg.accentHue) {
            cfg.accentHue = nh;
            cfg.accent = Gfx.hsv(nh, 0.62f, 1f);
        }
        cfg.accent = colorRow("acc", "Cor de destaque", cfg.accent);
        cfg.modOnColor = colorRow("mon", "Cor dos módulos ligados", cfg.modOnColor);
        if (button("rsta", "Restaurar aparência padrão")) cfg.resetAppearance();
    }

    private void perfTab() {
        section("Agora");
        info("FPS: " + Perf.fps() + "   |   RAM: " + Perf.usedMb() + " / " + Perf.maxMb() + " MB");

        section("Animações e efeitos");
        cfg.animations = toggleRow("anim", "Animações do menu", "Desligue para abrir/fechar instantâneo", cfg.animations, null);
        if (cfg.animations) cfg.animSpeed = slider("aspd", "Velocidade das animações", cfg.animSpeed, 0.5f, 3f, 0.1f, "%.1fx");
        cfg.hudShadows = toggleRow("shad", "Sombras do HUD", "Sombras de painéis e texto (desligar poupa FPS)", cfg.hudShadows, null);
        cfg.lowGlass = toggleRow("lowg", "Vidro simplificado", "Remove o gradiente/brilho dos painéis", cfg.lowGlass, null);
        cfg.hudUpdateMs = Math.round(slider("upd", "Atualização dos widgets (ms)", cfg.hudUpdateMs, 50, 1000, 50, "%.0f"));

        section("Com o menu aberto");
        cfg.perfParticles = toggleRow("pp", "Reduzir partículas", "Partículas mínimas enquanto o menu está aberto", cfg.perfParticles, null);
        cfg.perfEntities = toggleRow("pe", "Reduzir distância de entidades", "Entidades distantes somem enquanto o menu está aberto", cfg.perfEntities, null);
        cfg.perfFpsCap = toggleRow("pf", "Limitar FPS", "Poupa GPU/CPU enquanto você mexe no menu", cfg.perfFpsCap, null);
        if (cfg.perfFpsCap) cfg.perfFpsCapValue = Math.round(slider("pfv", "FPS máximo", cfg.perfFpsCapValue, 30, 240, 10, "%.0f"));

        section("Memória");
        cfg.clearCachesOnClose = toggleRow("cc", "Limpar caches ao fechar", "Descarta textos e layouts em cache", cfg.clearCachesOnClose, null);
        cfg.gcOnClose = toggleRow("gc", "Sugerir coleta de lixo ao fechar", "Pode causar um pequeno engasgo ao fechar", cfg.gcOnClose, null);
        if (button("clr", "Limpar caches agora")) Perf.clearCaches();
    }

    // ============================================================ controles (modo imediato)

    private float x0() { return vx0 + ind; }

    private float cw() { return cwFull - ind; }

    private boolean rowVisible(float y, float h) {
        return USE_SCISSOR ? (y + h >= vy0 && y <= vy1) : (y >= vy0 && y + h <= vy1);
    }

    private boolean over(float x, float y, float w, float h) {
        return viewHover && lx >= x && lx < x + w && ly >= y && ly < y + h;
    }

    private boolean canClick() {
        return pressed && drag == Drag.NONE;
    }

    /** Título de seção. */
    private void section(String text) {
        float y = curY + 4;
        curY += 20;
        if (!rowVisible(y, 14)) return;
        Gfx.text(g, tr, text.toUpperCase(Locale.ROOT), vx0 + 2, y + 1, cfg.accent, 0.95f, false);
        Gfx.fill(g, vx0 + 2, y + 11, cwFull - 4, 1, Gfx.rgba(cfg.accent, 0.25f));
    }

    /** Texto informativo de uma linha (não usa cache; para valores que mudam). */
    private void info(String text) {
        float y = curY;
        curY += 14;
        if (rowVisible(y, 12)) Gfx.text(g, tr, text, x0() + 4, y + 2, TXT, 0.9f, false);
    }

    /** Parágrafo de ajuda com quebra de linha (cache de quebra). */
    private void note(String text) {
        List<String> lines = Perf.wrap(tr, text, (int) cw() - 8);
        for (String s : lines) {
            float y = curY;
            curY += 11;
            if (rowVisible(y, 10)) Gfx.text(g, tr, s, x0() + 4, y, DIM, 0.95f, false);
        }
        curY += 3;
    }

    /**
     * Linha com switch. Se {@code expandKey != null}, mostra uma setinha à esquerda que
     * expande/recolhe as opções do mod.
     */
    private boolean toggleRow(String id, String title, String desc, boolean val, String expandKey) {
        float h = desc == null || desc.isEmpty() ? 22 : 30;
        float y = curY;
        curY += h + 3;
        if (!rowVisible(y, h)) return val;

        float x = x0(), w = cw();
        boolean hov = over(x, y, w, h);
        float hv = smooth("h:" + id, hov ? 1f : 0f);
        Gfx.roundRect(g, x, y, w, h, 4, Gfx.rgba(0xFFFFFF, 0.04f + 0.06f * hv));

        float textX = x + 8;
        if (expandKey != null) {
            boolean open = expanded.contains(expandKey);
            Gfx.text(g, tr, open ? "v" : ">", x + 6, y + (h - 9) / 2f, cfg.accent, 1f, false);
            textX = x + 18;
            if (hov && canClick() && lx < x + 18) {
                if (open) expanded.remove(expandKey); else expanded.add(expandKey);
                return val;
            }
        }

        float k = smooth("k:" + id, val ? 1f : 0f);
        float sx = x + w - 36, sy = y + (h - 14) / 2f;
        Gfx.roundRect(g, sx, sy, 28, 14, 7, Gfx.rgba(Gfx.lerp(0x3A3F4F, cfg.accent, k), 1f));
        Gfx.roundRect(g, sx + 2 + 14 * k, sy + 2, 10, 10, 5, Gfx.rgba(0xFFFFFF, 1f));

        int maxText = (int) (sx - textX - 8);
        int titleColor = val ? cfg.modOnColor : TXT;
        if (desc == null || desc.isEmpty()) {
            Gfx.text(g, tr, Perf.ellipsize(tr, title, maxText), textX, y + 7, titleColor, 1f, false);
        } else {
            Gfx.text(g, tr, Perf.ellipsize(tr, title, maxText), textX, y + 5, titleColor, 1f, false);
            Gfx.text(g, tr, Perf.ellipsize(tr, desc, maxText), textX, y + 17, DIM, 1f, false);
        }

        if (hov && canClick() && (expandKey == null || lx >= x + 18)) {
            changed = true;
            return !val;
        }
        return val;
    }

    /** Slider horizontal. Retorna o novo valor (arredondado ao passo). */
    private float slider(String id, String label, float val, float min, float max, float step, String fmt) {
        float h = 28;
        float y = curY;
        curY += h + 3;
        if (!rowVisible(y, h)) return val;

        float x = x0(), w = cw();
        float bx = x + 8, bw = w - 16, by = y + 18;
        boolean hit = over(bx - 4, y + 10, bw + 8, 16);
        boolean active = drag == Drag.SLIDER && id.equals(dragId);
        if (hit && canClick()) {
            drag = Drag.SLIDER;
            dragId = id;
            active = true;
        }
        if (active && down) {
            float p = clamp((lx - bx) / bw, 0f, 1f);
            float nv = min + p * (max - min);
            if (step > 0) nv = Math.round(nv / step) * step;
            nv = clamp(nv, min, max);
            if (nv != val) {
                val = nv;
                changed = true;
            }
        }

        float hv = smooth("h:" + id, hit || active ? 1f : 0f);
        Gfx.roundRect(g, x, y, w, h, 4, Gfx.rgba(0xFFFFFF, 0.04f + 0.04f * hv));
        Gfx.text(g, tr, label, x + 8, y + 4, TXT, 1f, false);
        String vs = String.format(Locale.ROOT, fmt, val);
        Gfx.text(g, tr, vs, x + w - 8 - tr.getWidth(vs), y + 4, cfg.accent, 1f, false);

        float p = max > min ? (val - min) / (max - min) : 0f;
        Gfx.roundRect(g, bx, by, bw, 4, 2, Gfx.rgba(0xFFFFFF, 0.12f));
        Gfx.roundRect(g, bx, by, Math.max(4f, bw * p), 4, 2, Gfx.rgba(cfg.accent, 1f));
        Gfx.roundRect(g, bx + bw * p - 4, by - 2, 8, 8, 4, Gfx.rgba(0xFFFFFF, 1f));
        return val;
    }

    /** Linha com paleta de cores. Retorna a cor escolhida. */
    private int colorRow(String id, String label, int cur) {
        float h = 24;
        float y = curY;
        curY += h + 3;
        if (!rowVisible(y, h)) return cur;

        float x = x0(), w = cw();
        Gfx.roundRect(g, x, y, w, h, 4, Gfx.rgba(0xFFFFFF, 0.04f));
        Gfx.text(g, tr, label, x + 8, y + 8, TXT, 1f, false);
        float total = SWATCHES.length * 14 + (SWATCHES.length - 1) * 4;
        float sx = x + w - 8 - total;
        for (int i = 0; i < SWATCHES.length; i++) {
            float cx = sx + i * 18, cy = y + 5;
            boolean hov = over(cx, cy, 14, 14);
            Gfx.roundRect(g, cx, cy, 14, 14, 3, Gfx.rgba(SWATCHES[i], 1f));
            if (SWATCHES[i] == (cur & 0xFFFFFF)) Gfx.outline(g, cx - 2, cy - 2, 18, 18, Gfx.rgba(0xFFFFFF, 0.95f));
            else if (hov) Gfx.outline(g, cx - 1, cy - 1, 16, 16, Gfx.rgba(0xFFFFFF, 0.5f));
            if (hov && canClick()) {
                cur = SWATCHES[i];
                changed = true;
            }
        }
        return cur;
    }

    /** Botão de ação. Retorna true no frame do clique. */
    private boolean button(String id, String label) {
        float h = 20;
        float y = curY;
        curY += h + 4;
        if (!rowVisible(y, h)) return false;
        float x = x0() + 4, w = tr.getWidth(label) + 22;
        boolean hov = over(x, y, w, h);
        float hv = smooth("h:" + id, hov ? 1f : 0f);
        Gfx.roundRect(g, x, y, w, h, 4, Gfx.rgba(cfg.accent, 0.18f + 0.30f * hv));
        Gfx.outline(g, x, y, w, h, Gfx.rgba(cfg.accent, 0.35f));
        Gfx.textC(g, tr, label, x + w / 2f, y + 6, 0xFFFFFF, 1f, false);
        return hov && canClick();
    }

    /** Filtro em "chips" que quebra de linha. Retorna a opção selecionada. */
    private String chips(List<String> opts, String sel) {
        float x = x0() + 2, y = curY;
        float right = x0() + cw();
        for (String o : opts) {
            float w = tr.getWidth(o) + 14;
            if (x + w > right) {
                x = x0() + 2;
                y += 20;
            }
            if (rowVisible(y, 16)) {
                boolean act = o.equals(sel);
                boolean hov = over(x, y, w, 16);
                float hv = smooth("c:" + o, hov ? 1f : 0f);
                Gfx.roundRect(g, x, y, w, 16, 8, act ? Gfx.rgba(cfg.accent, 0.85f) : Gfx.rgba(0xFFFFFF, 0.07f + 0.08f * hv));
                Gfx.textC(g, tr, o, x + w / 2f, y + 4, act ? 0x0B0E14 : TXT, 1f, false);
                if (hov && canClick()) sel = o;
            }
            x += w + 4;
        }
        curY = y + 22;
        return sel;
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
