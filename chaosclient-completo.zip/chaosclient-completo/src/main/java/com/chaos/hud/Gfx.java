package com.chaos.hud;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/**
 * Primitivas de desenho 2D usadas por todo o HUD.
 *
 * <p>Tudo passa por aqui para que o multiplicador global de alpha ({@link #alpha})
 * afete menu, widgets e textos de forma uniforme (é ele que faz o fade de abrir/fechar).
 * Nenhum método aloca objetos: seguro para chamar todo frame.</p>
 */
public final class Gfx {

    /** Multiplicador global de alpha (0..1). A tela o ajusta durante a animação. */
    public static float alpha = 1f;

    private Gfx() {}

    // ------------------------------------------------------------------ cores

    /** Monta uma cor ARGB a partir de RGB + alpha (0..1), já aplicando o alpha global. */
    public static int rgba(int rgb, float a) {
        int al = Math.max(0, Math.min(255, Math.round(a * alpha * 255f)));
        return (al << 24) | (rgb & 0xFFFFFF);
    }

    /** Interpola linearmente duas cores RGB. */
    public static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = Math.round(((a >> 16) & 0xFF) * (1 - t) + ((b >> 16) & 0xFF) * t);
        int g = Math.round(((a >> 8) & 0xFF) * (1 - t) + ((b >> 8) & 0xFF) * t);
        int bl = Math.round((a & 0xFF) * (1 - t) + (b & 0xFF) * t);
        return (r << 16) | (g << 8) | bl;
    }

    /** HSV (0..1) para RGB 0xRRGGBB. */
    public static int hsv(float h, float s, float v) {
        float hh = (h - (float) Math.floor(h)) * 6f;
        int i = (int) hh;
        float f = hh - i;
        float p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s);
        float r, g, b;
        switch (i % 6) {
            case 0 -> { r = v; g = t; b = p; }
            case 1 -> { r = q; g = v; b = p; }
            case 2 -> { r = p; g = v; b = t; }
            case 3 -> { r = p; g = q; b = v; }
            case 4 -> { r = t; g = p; b = v; }
            default -> { r = v; g = p; b = q; }
        }
        return (Math.round(r * 255) << 16) | (Math.round(g * 255) << 8) | Math.round(b * 255);
    }

    // ------------------------------------------------------------- retângulos

    /** Retângulo simples (coordenadas float são arredondadas). */
    public static void fill(DrawContext g, float x, float y, float w, float h, int argb) {
        if ((argb >>> 24) == 0 || w <= 0 || h <= 0) return;
        int x1 = Math.round(x), y1 = Math.round(y);
        g.fill(x1, y1, Math.round(x + w), Math.round(y + h), argb);
    }

    /** Retângulo com cantos arredondados (raio em pixels, recomendado 2..8). */
    public static void roundRect(DrawContext g, float fx, float fy, float fw, float fh, int r, int argb) {
        if ((argb >>> 24) == 0) return;
        int x = Math.round(fx), y = Math.round(fy), w = Math.round(fw), h = Math.round(fh);
        if (w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) { g.fill(x, y, x + w, y + h, argb); return; }
        g.fill(x, y + r, x + w, y + h - r, argb);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
            g.fill(x + inset, y + i, x + w - inset, y + i + 1, argb);
            g.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, argb);
        }
    }

    /** Contorno de 1px. */
    public static void outline(DrawContext g, float x, float y, float w, float h, int argb) {
        fill(g, x, y, w, 1, argb);
        fill(g, x, y + h - 1, w, 1, argb);
        fill(g, x, y + 1, 1, h - 2, argb);
        fill(g, x + w - 1, y + 1, 1, h - 2, argb);
    }

    /** Sombra suave (camadas translúcidas). Só é chamada se {@code hudShadows} estiver ligado. */
    public static void shadow(DrawContext g, float x, float y, float w, float h, int r) {
        for (int i = 5; i >= 1; i--) {
            roundRect(g, x - i, y - i + 2, w + 2 * i, h + 2 * i, r + i, rgba(0x000000, 0.045f));
        }
    }

    /**
     * Painel "glassmorphism": base escura translúcida, brilho no topo e borda clara fina.
     * O modo {@code lowGlass} remove o gradiente (mais barato).
     */
    public static void glass(DrawContext g, float x, float y, float w, float h, int r, float opacity, HudConfig c) {
        if (c.hudShadows) shadow(g, x, y, w, h, r);
        roundRect(g, x, y, w, h, r, rgba(0x0E1118, opacity));
        int X = Math.round(x), Y = Math.round(y), W = Math.round(w), H = Math.round(h);
        if (!c.lowGlass) {
            g.fillGradient(X + r, Y + 1, X + W - r, Y + Math.max(2, H / 3),
                    rgba(0xFFFFFF, 0.10f), rgba(0xFFFFFF, 0f));
        }
        int bc = rgba(0xFFFFFF, 0.16f);
        g.fill(X + r, Y, X + W - r, Y + 1, bc);
        g.fill(X + r, Y + H - 1, X + W - r, Y + H, rgba(0xFFFFFF, 0.07f));
        g.fill(X, Y + r, X + 1, Y + H - r, bc);
        g.fill(X + W - 1, Y + r, X + W, Y + H - r, bc);
    }

    // ------------------------------------------------------------------ texto

    /**
     * Texto com alpha. O Minecraft trata alpha &lt; 4 como opaco, então textos quase
     * invisíveis são simplesmente ignorados.
     */
    public static void text(DrawContext g, TextRenderer tr, String s, float x, float y, int rgb, float a, boolean shadow) {
        int c = rgba(rgb, a);
        if ((c >>> 24) < 8) return;
        g.drawText(tr, s, Math.round(x), Math.round(y), c, shadow);
    }

    /** Texto centralizado horizontalmente em {@code cx}. */
    public static void textC(DrawContext g, TextRenderer tr, String s, float cx, float y, int rgb, float a, boolean shadow) {
        text(g, tr, s, cx - tr.getWidth(s) / 2f, y, rgb, a, shadow);
    }
}
