package com.chaos.hud;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import org.joml.Matrix3x2fStack;

import java.util.List;
import java.util.function.Supplier;

/**
 * Widget de HUD (FPS, coordenadas, lista de mods...).
 *
 * <ul>
 *   <li>O conteúdo vem de um {@code Supplier<List<String>>} e só é recalculado a cada
 *       {@code hudUpdateMs} (limita a taxa de atualização de elementos de fundo);
 *       entre as atualizações o desenho usa texto e largura em cache.</li>
 *   <li>Posição é normalizada (0..1) e escala é livre (0,5x a 3x); ambas são salvas na config.</li>
 * </ul>
 */
public final class HudWidget {

    private static final int PX = 5, PY = 4, LH = 10;

    public final String id;
    public final String name;
    private final Supplier<List<String>> source;
    private final boolean modColor;
    private final boolean defEnabled;
    private final float defX, defY;

    private List<String> lines = List.of();
    private boolean empty = true;
    private int w = 40, h = 18;
    private long lastNs;

    public HudWidget(String id, String name, boolean defEnabled, float defX, float defY,
                     boolean modColor, Supplier<List<String>> source) {
        this.id = id;
        this.name = name;
        this.defEnabled = defEnabled;
        this.defX = defX;
        this.defY = defY;
        this.modColor = modColor;
        this.source = source;
    }

    public HudConfig.WidgetState state() {
        return HudConfig.get().widgets.computeIfAbsent(id, k -> new HudConfig.WidgetState(defEnabled, defX, defY));
    }

    public void resetState() {
        HudConfig.get().widgets.put(id, new HudConfig.WidgetState(defEnabled, defX, defY));
    }

    /** Força recálculo no próximo refresh (usado ao limpar caches). */
    void invalidate() {
        lastNs = 0;
    }

    // --------------------------------------------------------------- conteúdo

    /** Atualiza texto/tamanho se já passou o intervalo configurado. */
    public void refresh(TextRenderer tr, boolean force) {
        long now = System.nanoTime();
        long interval = HudConfig.get().hudUpdateMs * 1_000_000L;
        if (!force && lastNs != 0 && now - lastNs < interval) return;
        lastNs = now;
        List<String> l;
        try {
            l = source.get();
        } catch (Throwable t) {
            l = List.of();
        }
        lines = l == null ? List.of() : l;
        empty = lines.isEmpty();
        int maxW;
        int count;
        if (empty) {
            maxW = tr.getWidth("(" + name + ")");
            count = 1;
        } else {
            maxW = 0;
            for (String s : lines) maxW = Math.max(maxW, tr.getWidth(s));
            count = lines.size();
        }
        w = maxW + PX * 2;
        h = count * LH + PY * 2 - 1;
    }

    // --------------------------------------------------------------- geometria

    /** Retângulo em pixels de tela: {x, y, largura, altura} (já com escala). */
    public float[] rect(int sw, int sh) {
        HudConfig.WidgetState st = state();
        float ww = w * st.scale, hh = h * st.scale;
        return new float[]{st.nx * Math.max(0, sw - ww), st.ny * Math.max(0, sh - hh), ww, hh};
    }

    public boolean hit(float mx, float my, int sw, int sh) {
        float[] r = rect(sw, sh);
        return mx >= r[0] && mx < r[0] + r[2] && my >= r[1] && my < r[1] + r[3];
    }

    /** Alça de redimensionamento (canto inferior direito). */
    public boolean hitHandle(float mx, float my, int sw, int sh) {
        float[] r = rect(sw, sh);
        return mx >= r[0] + r[2] - 9 && mx < r[0] + r[2] + 2 && my >= r[1] + r[3] - 9 && my < r[1] + r[3] + 2;
    }

    public void moveTo(float px, float py, int sw, int sh) {
        HudConfig.WidgetState st = state();
        float ww = w * st.scale, hh = h * st.scale;
        st.nx = sw - ww <= 0 ? 0 : Math.max(0f, Math.min(1f, px / (sw - ww)));
        st.ny = sh - hh <= 0 ? 0 : Math.max(0f, Math.min(1f, py / (sh - hh)));
    }

    /** Redimensiona arrastando o canto: a escala acompanha a distância ao canto superior esquerdo. */
    public void resizeTo(float mx, float my, int sw, int sh) {
        HudConfig.WidgetState st = state();
        float[] r = rect(sw, sh);
        float ns = Math.max(0.5f, Math.min(3f, Math.max((mx - r[0]) / w, (my - r[1]) / h)));
        float oldX = r[0], oldY = r[1];
        st.scale = ns;
        moveTo(oldX, oldY, sw, sh); // mantém o canto superior esquerdo no lugar
    }

    // ----------------------------------------------------------------- desenho

    /**
     * Desenha o widget.
     *
     * @param edit   true com o menu aberto (mostra contorno e alça de redimensionar)
     * @param active true se está sob o mouse ou sendo arrastado
     */
    public void draw(DrawContext g, TextRenderer tr, int sw, int sh, boolean edit, boolean active) {
        if (empty && !edit) return;
        HudConfig c = HudConfig.get();
        HudConfig.WidgetState st = state();
        float[] r = rect(sw, sh);

        Matrix3x2fStack m = g.getMatrices();
        m.pushMatrix();
        m.translate(r[0], r[1]);
        m.scale(st.scale, st.scale);
        try {
            if (c.hudBackground || edit) {
                if (c.hudShadows) Gfx.shadow(g, 0, 0, w, h, 4);
                float op = c.hudBackground ? c.hudBgOpacity : 0.25f;
                Gfx.roundRect(g, 0, 0, w, h, 4, Gfx.rgba(0x0E1118, op));
            }
            if (empty) {
                Gfx.text(g, tr, "(" + name + ")", PX, PY, 0x8A90A0, 1f, false);
            } else {
                int color = modColor ? c.modOnColor : c.hudTextColor;
                for (int i = 0; i < lines.size(); i++) {
                    Gfx.text(g, tr, lines.get(i), PX, PY + i * LH, color, 1f, c.hudShadows);
                }
            }
            if (edit) {
                Gfx.outline(g, 0, 0, w, h, Gfx.rgba(c.accent, active ? 0.95f : 0.5f));
                Gfx.roundRect(g, w - 6, h - 6, 6, 6, 2, Gfx.rgba(c.accent, active ? 1f : 0.75f));
                if (active) Gfx.text(g, tr, name, 0, -11, 0xE6E9F2, 0.9f, true);
            }
        } finally {
            m.popMatrix();
        }
    }
}
