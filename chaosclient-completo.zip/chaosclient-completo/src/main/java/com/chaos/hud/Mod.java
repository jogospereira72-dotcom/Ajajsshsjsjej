package com.chaos.hud;

import java.util.ArrayList;
import java.util.List;

/**
 * Abstração de "mod" exibida na aba Mods.
 *
 * <p>Para adicionar uma função nova ao menu basta criar uma subclasse, declarar as
 * opções com {@link #add(Setting)} e registrá-la em {@link ModCatalog#register(Mod)}.
 * Os módulos já existentes do ChaosClient ({@code com.chaos.Module}) são adaptados
 * automaticamente pelo catálogo, sem mudar nenhuma linha neles.</p>
 */
public abstract class Mod {

    public final String id;
    public final String name;
    public final String description;
    public String category;
    private final List<Setting> settings = new ArrayList<>();

    protected Mod(String id, String name, String description, String category) {
        this.id = id;
        this.name = name;
        this.description = description == null ? "" : description;
        this.category = category;
    }

    public abstract boolean isEnabled();

    public abstract void setEnabled(boolean enabled);

    /** Se true, o estado ligado/desligado é restaurado sempre ao entrar no mundo. */
    public boolean persistAlways() {
        return false;
    }

    public List<Setting> settings() {
        return settings;
    }

    protected <T extends Setting> T add(T s) {
        s.owner = this;
        settings.add(s);
        return s;
    }

    // ---------------------------------------------------------------- settings

    /** Opção configurável de um mod. O valor é salvo automaticamente na config JSON. */
    public abstract static class Setting {
        public final String key;
        public final String label;
        Mod owner;

        protected Setting(String key, String label) {
            this.key = key;
            this.label = label;
        }

        String cfgKey() {
            return owner.id + "." + key;
        }
    }

    /** Opção liga/desliga. */
    public static final class BoolSetting extends Setting {
        private final boolean def;

        public BoolSetting(String key, String label, boolean def) {
            super(key, label);
            this.def = def;
        }

        public boolean get() {
            Float f = HudConfig.get().modSettings.get(cfgKey());
            return f == null ? def : f > 0.5f;
        }

        public void set(boolean v) {
            HudConfig c = HudConfig.get();
            c.modSettings.put(cfgKey(), v ? 1f : 0f);
            c.markDirty();
        }
    }

    /** Opção numérica (slider). */
    public static final class FloatSetting extends Setting {
        public final float min, max, step;
        private final float def;

        public FloatSetting(String key, String label, float min, float max, float step, float def) {
            super(key, label);
            this.min = min;
            this.max = max;
            this.step = step;
            this.def = def;
        }

        public float get() {
            Float f = HudConfig.get().modSettings.get(cfgKey());
            return f == null ? def : Math.max(min, Math.min(max, f));
        }

        public void set(float v) {
            HudConfig c = HudConfig.get();
            c.modSettings.put(cfgKey(), Math.max(min, Math.min(max, v)));
            c.markDirty();
        }
    }
}
