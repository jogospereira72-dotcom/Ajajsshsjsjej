# ChaosClient completo — Minecraft 1.21.11

Este projeto usa Java 21, Fabric Loader, Fabric API e Loom 1.14. A interface gráfica foi feita com as telas nativas do Minecraft (`Screen`, `DrawContext` e `TextRenderer`), portanto não precisa de Cloth Config, Architectury, Forge Config API ou outra biblioteca gráfica externa.

O Gson já é fornecido pelo próprio Minecraft e é usado apenas para guardar a configuração em `.minecraft/config/chaosclient-hud.json`.

## Compilar pelo GitHub

1. Envie o conteúdo desta pasta para a raiz de um repositório GitHub.
2. Confirme que `build.gradle`, `gradlew`, `settings.gradle`, `gradle.properties` e `src/` estão na raiz.
3. Abra **Actions** e execute **Build ChaosClient 1.21.11**.
4. Baixe o artefacto **chaosclient-1.21.11** da execução concluída.
5. Coloque o JAR em `mods`, juntamente com o Fabric API de Minecraft 1.21.11.

O workflow instala Java 21, dá permissão ao Gradle Wrapper e executa `./gradlew clean build --no-daemon`.

## Dependências usadas no build.gradle

- Minecraft 1.21.11.
- Yarn mappings 1.21.11+build.4.
- Fabric Loader 0.18.4 ou superior.
- Fabric API 0.141.3+1.21.11.
- Loom 1.14-SNAPSHOT.

Não adicione outras bibliotecas para a interface. Adicionar versões incompatíveis de Cloth Config, Mod Menu ou Architectury pode causar conflitos. Mod Menu é opcional e serve apenas para listar o mod; não é necessário para abrir o menu pela tecla X.

## Uso

Dentro de um mundo, pressione **X** para abrir o menu. As abas são Mods, HUD, Aparência e Desempenho. Pressione **ESC** ou **X** para fechar.
