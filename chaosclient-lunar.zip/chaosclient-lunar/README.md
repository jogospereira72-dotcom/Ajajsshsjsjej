# ChaosClient — Minecraft 1.21.11 (Fabric)

Cliente no estilo Lunar: tela inicial própria, menu in-game (tecla **X**), HUD arrastável e
pack de desempenho.

## Como compilar pelo GitHub
1. Envie TODO o conteúdo desta pasta para a raiz de um repositório (inclusive `.github/`).
2. Aba **Actions** → **Build ChaosClient 1.21.11** → **Run workflow**.
3. Quando terminar, baixe em *Artifacts*:
   - **ChaosClient-Pack-1.21.11** ← use este: contém o JAR + Fabric API + Sodium + Lithium +
     FerriteCore + EntityCulling + ImmediatelyFast (baixados do Modrinth).
   - **chaosclient-1.21.11**: só o JAR do cliente.
4. Instale o Fabric Loader (1.21.11) e copie os `.jar` da pasta `mods/` do pack para `.minecraft/mods`.

## O que tem
- **Tela inicial do ChaosClient** (Um jogador, Multijogador, Menu do Client, Opções, Sair).
  Desligue em X → Aparência → "Tela inicial do ChaosClient".
- **Menu X**: abas Mods, HUD, Aparência, Desempenho; janelas e widgets arrastáveis; config em
  `config/chaosclient-hud.json`.
- **Widgets**: FPS, coordenadas, RAM, relógio, CPS, teclas (WASD), lista de mods.
- **Perfil Max FPS**: aplicado 1x na primeira execução e disponível em X → Desempenho.
- **Minimapa** no canto superior direito (arraste/redimensione com X aberto; configuração na aba Minimapa).
- **Navegador de itens (JEI)**: tecla **J** (ou aba Itens). Busca, receitas de craft, fornalha, cortador de
  pedra e ferraria, e "usos" de cada item. Lê as receitas do próprio Minecraft (não inclui receitas de outros mods).
- **Abas do menu X**: Mods, HUD, Minimapa, Itens, Aparência, Desempenho.
- **Módulos**: veja `ChaosClient.java` (exemplo: Sprint Automático). Novos módulos aparecem sozinhos.

## Sobre FPS
O ganho grande vem do **Sodium/Lithium/etc. do pack**; o perfil Max FPS ajusta as opções do jogo.
O código do menu em si só poupa recursos (ele não "acelera" o Minecraft sozinho).
