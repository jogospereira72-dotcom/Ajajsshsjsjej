package com.chaos;

import net.minecraft.client.MinecraftClient;

/** Módulo base do cliente. Sobrescreva {@code onEnable/onDisable/onTick} para dar função a ele. */
public abstract class Module {
    public final String name;
    public final String description;
    private boolean enabled;

    protected Module(String name, String description) {
        this.name = name;
        this.description = description == null ? "" : description;
    }

    public final boolean isEnabled() {
        return enabled;
    }

    public final void toggle() {
        setEnabled(!enabled);
    }

    public final void setEnabled(boolean value) {
        if (enabled == value) return;
        enabled = value;
        if (value) onEnable(); else onDisable();
    }

    /** Chamado todo tick pelo ChaosClient enquanto o módulo estiver ligado. */
    public final void tick(MinecraftClient mc) {
        if (enabled) onTick(mc);
    }

    protected void onEnable() {}
    protected void onDisable() {}
    protected void onTick(MinecraftClient mc) {}
}
