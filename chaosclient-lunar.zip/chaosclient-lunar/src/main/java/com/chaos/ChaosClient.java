package com.chaos;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

/** Entrypoint do ChaosClient. Os módulos registrados aqui aparecem na aba Mods do menu (tecla X). */
public final class ChaosClient implements ClientModInitializer {
    public static final List<Module> MODULES = new ArrayList<>();

    @Override
    public void onInitializeClient() {
        registerDefaults();
        ClientTickEvents.END_CLIENT_TICK.register(ChaosClient::tick);
    }

    private static void registerDefaults() {
        if (!MODULES.isEmpty()) return;

        // Exemplo de módulo real: mantém o sprint ligado enquanto você anda para frente.
        MODULES.add(new Module("Sprint Automático", "Corre sozinho enquanto você anda para frente") {
            @Override
            protected void onTick(MinecraftClient mc) {
                if (mc.player == null) return;
                if (mc.options.forwardKey.isPressed() && !mc.options.sneakKey.isPressed()) {
                    mc.options.sprintKey.setPressed(true);
                }
            }

            @Override
            protected void onDisable() {
                MinecraftClient mc = MinecraftClient.getInstance();
                if (mc.options != null) mc.options.sprintKey.setPressed(false);
            }
        });
    }

    private static void tick(MinecraftClient client) {
        for (Module m : MODULES) {
            try {
                m.tick(client);
            } catch (Throwable t) {
                System.err.println("[ChaosClient] erro no módulo " + m.name + ", desligando: " + t);
                m.setEnabled(false);
            }
        }
    }
}
