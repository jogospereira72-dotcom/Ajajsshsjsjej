package com.chaos.hud;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;

import java.util.ArrayList;
import java.util.List;

/**
 * Minimapa (widget do HUD, canto superior direito por padrão).
 *
 * <p>Como é barato: o mapa NÃO é refeito todo frame. A cada {@code minimapUpdateMs} o terreno
 * ao redor é amostrado (bloco mais alto de cada coluna + cor de mapa do bloco) e convertido em
 * "faixas" horizontais de mesma cor; o desenho de cada frame são só alguns retângulos.
 * Norte fica sempre para cima.</p>
 */
public final class Minimap implements HudWidget.Painter {

    private long lastUpdate;
    private boolean hasData;
    private int radius = 24, cells = 49;
    private float yaw;
    /** Faixas: {linha, coluna, comprimento, corRGB}. */
    private List<int[]> runs = new ArrayList<>();
    /** Pontos: {dx*10, dz*10, tipo} (0 = jogador, 1 = hostil, 2 = animal). */
    private List<int[]> dots = new ArrayList<>();

    @Override
    public int size() {
        return HudConfig.get().minimapSize;
    }

    @Override
    public void refresh(MinecraftClient mc) {
        HudConfig c = HudConfig.get();
        long now = System.currentTimeMillis();
        if (hasData && now - lastUpdate < c.minimapUpdateMs) return;
        lastUpdate = now;
        ClientWorld world = mc.world;
        if (world == null || mc.player == null) {
            hasData = false;
            return;
        }
        rebuild(mc, world, c);
    }

    private void rebuild(MinecraftClient mc, ClientWorld world, HudConfig c) {
        radius = c.minimapRadius;
        cells = radius * 2 + 1;
        int px = (int) Math.floor(mc.player.getX());
        int pz = (int) Math.floor(mc.player.getZ());
        int py = (int) Math.floor(mc.player.getY());
        yaw = mc.player.getYaw();
        boolean ceiling = world.getDimension().hasCeiling();

        int[][] color = new int[cells][cells];
        int[][] height = new int[cells][cells];
        boolean[][] water = new boolean[cells][cells];
        BlockPos.Mutable pos = new BlockPos.Mutable();

        for (int r = 0; r < cells; r++) {
            for (int col = 0; col < cells; col++) {
                int x = px + col - radius, z = pz + r - radius;
                if (!world.isChunkLoaded(x >> 4, z >> 4)) {
                    height[r][col] = Integer.MIN_VALUE;
                    continue;
                }
                int y;
                if (ceiling) { // Nether/End: procura o chão perto do jogador
                    y = py + 2;
                    int min = py - 40;
                    while (y > min) {
                        pos.set(x, y, z);
                        if (!world.getBlockState(pos).isAir()) break;
                        y--;
                    }
                } else {
                    y = world.getTopY(Heightmap.Type.WORLD_SURFACE, x, z) - 1;
                }
                pos.set(x, y, z);
                BlockState state = world.getBlockState(pos);
                int rgb = state.getMapColor(world, pos).color;
                color[r][col] = rgb == 0 ? 0x1A1D26 : rgb;
                height[r][col] = y;
                water[r][col] = !state.getFluidState().isEmpty();
            }
        }

        // sombreamento por relevo (compara com o vizinho ao norte) + quantização das cores
        List<int[]> newRuns = new ArrayList<>();
        for (int r = 0; r < cells; r++) {
            int runStart = 0, runColor = -1;
            for (int col = 0; col <= cells; col++) {
                int shaded = -2;
                if (col < cells) {
                    if (height[r][col] == Integer.MIN_VALUE) {
                        shaded = 0x0B0D12;
                    } else {
                        int rgb = color[r][col];
                        if (c.minimapShade && !water[r][col] && r > 0 && height[r - 1][col] != Integer.MIN_VALUE) {
                            int dh = height[r][col] - height[r - 1][col];
                            rgb = dh > 0 ? scale(rgb, 1.15f) : dh < 0 ? scale(rgb, 0.80f) : rgb;
                        }
                        shaded = rgb & 0xF0F0F0; // 4 bits por canal: junta mais faixas
                    }
                }
                if (shaded != runColor) {
                    if (runColor != -1) newRuns.add(new int[]{r, runStart, col - runStart, runColor});
                    runStart = col;
                    runColor = shaded;
                }
            }
        }
        runs = newRuns;

        // entidades próximas
        List<int[]> newDots = new ArrayList<>();
        for (Entity e : world.getEntities()) {
            if (e == mc.player || newDots.size() >= 80) continue;
            int type = e instanceof PlayerEntity ? 0 : e instanceof HostileEntity ? 1 : e instanceof AnimalEntity ? 2 : -1;
            if (type < 0) continue;
            if (type == 0 && !c.minimapPlayers) continue;
            if (type == 1 && !c.minimapHostile) continue;
            if (type == 2 && !c.minimapAnimals) continue;
            double dx = e.getX() - mc.player.getX(), dz = e.getZ() - mc.player.getZ();
            if (Math.abs(dx) > radius || Math.abs(dz) > radius) continue;
            newDots.add(new int[]{(int) (dx * 10), (int) (dz * 10), type});
        }
        dots = newDots;
        hasData = true;
    }

    private static int scale(int rgb, float f) {
        int r = Math.min(255, Math.round(((rgb >> 16) & 0xFF) * f));
        int g = Math.min(255, Math.round(((rgb >> 8) & 0xFF) * f));
        int b = Math.min(255, Math.round((rgb & 0xFF) * f));
        return (r << 16) | (g << 8) | b;
    }

    @Override
    public void paint(DrawContext g, TextRenderer tr, int s, boolean edit) {
        HudConfig c = HudConfig.get();
        Gfx.roundRect(g, 0, 0, s, s, 4, Gfx.rgba(0x0B0D12, 0.92f));
        if (!hasData) {
            Gfx.textC(g, tr, "Minimapa", s / 2f, s / 2f - 4, 0x8A90A0, 1f, false);
        } else {
            float cell = (s - 4) / (float) cells;
            float ox = 2, oy = 2;
            for (int[] run : runs) {
                Gfx.fill(g, ox + run[1] * cell, oy + run[0] * cell, run[2] * cell, cell, Gfx.rgba(run[3], c.minimapOpacity));
            }
            for (int[] d : dots) {
                int col = d[2] == 0 ? 0x37D6E8 : d[2] == 1 ? 0xFF4A5A : 0x5CFF7A;
                float x = ox + (d[0] / 10f + radius + 0.5f) * cell, y = oy + (d[1] / 10f + radius + 0.5f) * cell;
                Gfx.fill(g, x - 1.5f, y - 1.5f, 3, 3, Gfx.rgba(col, 1f));
            }
            // jogador: quadrado branco + ponta na direção do olhar
            float cx = s / 2f, cy = s / 2f;
            double rad = Math.toRadians(yaw);
            float dx = (float) -Math.sin(rad) * 5f, dz = (float) Math.cos(rad) * 5f;
            Gfx.fill(g, cx - 1.5f, cy - 1.5f, 3, 3, Gfx.rgba(0xFFFFFF, 1f));
            Gfx.fill(g, cx + dx - 1, cy + dz - 1, 2, 2, Gfx.rgba(0xFFFFFF, 0.9f));
            Gfx.textC(g, tr, "N", s / 2f, 3, 0xFFFFFF, 0.85f, true);
        }
        Gfx.outline(g, 0, 0, s, s, Gfx.rgba(c.accent, 0.6f));
    }
}
