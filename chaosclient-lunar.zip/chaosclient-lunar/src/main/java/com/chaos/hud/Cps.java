package com.chaos.hud;

import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;

/**
 * Contador de cliques por segundo. Lê o estado do mouse a cada frame (e não a cada tick),
 * assim cliques rápidos não se perdem.
 */
public final class Cps {

    private static final ArrayDeque<Long> LEFT = new ArrayDeque<>();
    private static final ArrayDeque<Long> RIGHT = new ArrayDeque<>();
    private static boolean prevLeft, prevRight;

    private Cps() {}

    /** Chamar uma vez por frame. */
    public static void poll(long window) {
        long now = System.currentTimeMillis();
        boolean l = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        if (l && !prevLeft) LEFT.addLast(now);
        if (r && !prevRight) RIGHT.addLast(now);
        prevLeft = l;
        prevRight = r;
        purge(LEFT, now);
        purge(RIGHT, now);
    }

    private static void purge(ArrayDeque<Long> q, long now) {
        while (!q.isEmpty() && now - q.peekFirst() > 1000) q.pollFirst();
    }

    public static int left() {
        return LEFT.size();
    }

    public static int right() {
        return RIGHT.size();
    }
}
