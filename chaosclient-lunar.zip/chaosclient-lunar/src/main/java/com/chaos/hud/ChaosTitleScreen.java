package com.chaos.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;
import org.joml.Matrix3x2fStack;
import org.lwjgl.glfw.GLFW;

/**
 * Tela inicial do ChaosClient (substitui o menu principal do Minecraft, como no Lunar Client).
 *
 * <p>Fundo escuro com gradiente na cor de destaque e partículas flutuando (desenho 2D barato,
 * sem imagens), logo grande e botões de vidro com animação ao passar o mouse. Cliques são
 * lidos direto do GLFW, como no resto do HUD.</p>
 */
public final class ChaosTitleScreen extends Screen {

    private static final String[] LABELS = {"Um jogador", "Multijogador", "Menu do Client (X)", "Opções", "Sair do jogo"};
    private static final int BTN_W = 230, BTN_H = 28, GAP = 8, PARTICLES = 36;

    private final MinecraftClient mc = MinecraftClient.getInstance();
    private final HudConfig cfg = HudConfig.get();
    private final float[] hover = new float[LABELS.length];
    private final float[] px = new float[PARTICLES], py = new float[PARTICLES],
            ps = new float[PARTICLES], pv = new float[PARTICLES], pa = new float[PARTICLES];
    private final long t0 = System.nanoTime();
    private long lastNs = t0;
    private boolean prevDown = true; // se o mouse já estava apertado ao abrir, não conta como clique

    public ChaosTitleScreen() {
        super(Text.literal("ChaosClient"));
        java.util.Random r = new java.util.Random(7);
        for (int i = 0; i < PARTICLES; i++) {
            px[i] = r.nextFloat();
            py[i] = r.nextFloat();
            ps[i] = 3 + r.nextInt(7);
            pv[i] = 0.01f + r.nextFloat() * 0.03f;
            pa[i] = 0.05f + r.nextFloat() * 0.12f;
        }
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false; // no menu principal o ESC não faz nada
    }

    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        TextRenderer tr = mc.textRenderer;
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastNs) / 1e9f);
        lastNs = now;
        float t = cfg.animations ? (now - t0) / 1e9f : 0f;
        Gfx.alpha = 1f;
        Perf.frame();

        boolean down = GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean clicked = down && !prevDown;
        prevDown = down;

        // ---- fundo
        int accent = cfg.accent;
        g.fillGradient(0, 0, width, height, 0xFF07090F, 0xFF000000 | Gfx.lerp(0x07090F, accent, 0.22f));
        for (int i = 0; i < PARTICLES; i++) {
            float y = ((py[i] - t * pv[i]) % 1f + 1f) % 1f;
            float x = px[i] + (float) Math.sin(t * 0.3f + i) * 0.01f;
            Gfx.fill(g, x * width, y * height, ps[i], ps[i], Gfx.rgba(accent, pa[i]));
        }

        // ---- logo
        float cx = width / 2f;
        int total = LABELS.length * (BTN_H + GAP) - GAP;
        float top = Math.max(70f, (height - total) / 2f + 30f);
        Matrix3x2fStack m = g.getMatrices();
        m.pushMatrix();
        m.translate(cx, top - 62);
        m.scale(4f, 4f);
        Gfx.textC(g, tr, "§lCHAOS", 0, 0, accent, 1f, true);
        m.popMatrix();
        Gfx.textC(g, tr, "C L I E N T", cx, top - 22, 0xE6E9F2, 0.9f, true);

        // ---- botões
        for (int i = 0; i < LABELS.length; i++) {
            float x = cx - BTN_W / 2f, y = top + i * (BTN_H + GAP);
            boolean hov = mx >= x && mx < x + BTN_W && my >= y && my < y + BTN_H;
            hover[i] += ((hov ? 1f : 0f) - hover[i]) * (cfg.animations ? 1f - (float) Math.exp(-16f * dt) : 1f);
            float h = hover[i];
            float grow = 3f * h;
            Gfx.glass(g, x - grow, y - grow / 2f, BTN_W + grow * 2, BTN_H + grow, 6, 0.55f + 0.2f * h, cfg);
            Gfx.roundRect(g, x - grow, y - grow / 2f, 3, BTN_H + grow, 1, Gfx.rgba(accent, 0.4f + 0.6f * h));
            Gfx.textC(g, tr, LABELS[i], cx, y + 10, Gfx.lerp(0xC9CEDB, 0xFFFFFF, h), 1f, false);
            if (hov && clicked) activate(i);
        }

        // ---- rodapé
        Gfx.text(g, tr, "ChaosClient 1.1.0  |  Minecraft 1.21.11", 8, height - 14, 0x8A90A0, 0.9f, true);
        String fps = Perf.fps() + " FPS";
        Gfx.text(g, tr, fps, width - 8 - tr.getWidth(fps), height - 14, 0x8A90A0, 0.9f, true);
        Gfx.textC(g, tr, "Dentro do jogo, aperte X para abrir o menu", cx, height - 14, 0x8A90A0, 0.8f, true);
    }

    private void activate(int i) {
        switch (i) {
            case 0 -> mc.setScreen(new SelectWorldScreen(this));
            case 1 -> mc.setScreen(new MultiplayerScreen(this));
            case 2 -> mc.setScreen(new HudScreen(this));
            case 3 -> mc.setScreen(new OptionsScreen(this, mc.options));
            default -> mc.scheduleStop();
        }
    }
}
