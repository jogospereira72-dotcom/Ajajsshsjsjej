package com.chaos.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Lista de widgets do HUD. Para criar um novo, adicione uma linha em {@link #build()}:
 * id, nome, ligado por padrão, posição inicial (0..1), usa cor de "módulo ligado", e o
 * fornecedor das linhas de texto.
 */
public final class WidgetRegistry {

    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static final String[] DIRS = {"S", "SO", "O", "NO", "N", "NE", "L", "SE"};
    private static List<HudWidget> widgets;

    private WidgetRegistry() {}

    public static List<HudWidget> all() {
        if (widgets == null) widgets = build();
        return widgets;
    }

    private static List<HudWidget> build() {
        List<HudWidget> l = new ArrayList<>();

        l.add(new HudWidget("minimap", "Minimapa", true, 0.99f, 0.02f, new Minimap()));

        l.add(new HudWidget("fps", "FPS", true, 0.01f, 0.02f, false,
                () -> List.of("FPS: " + Perf.fps())));

        l.add(new HudWidget("coords", "Coordenadas", true, 0.01f, 0.10f, false, () -> {
            var p = MinecraftClient.getInstance().player;
            if (p == null) return List.of();
            float yaw = (MathHelper.wrapDegrees(p.getYaw()) + 360f) % 360f;
            String dir = DIRS[Math.round(yaw / 45f) % 8];
            return List.of(
                    String.format(Locale.ROOT, "XYZ: %.1f / %.1f / %.1f", p.getX(), p.getY(), p.getZ()),
                    "Direção: " + dir);
        }));

        l.add(new HudWidget("memory", "Memória", false, 0.01f, 0.20f, false,
                () -> List.of("RAM: " + Perf.usedMb() + " / " + Perf.maxMb() + " MB")));

        l.add(new HudWidget("clock", "Relógio", false, 0.45f, 0.02f, false,
                () -> List.of(LocalTime.now().format(CLOCK))));

        l.add(new HudWidget("cps", "CPS", false, 0.01f, 0.26f, false, true,
                () -> List.of("CPS: " + Cps.left() + " | " + Cps.right())));

        l.add(new HudWidget("keys", "Teclas", false, 0.01f, 0.34f, false, true, () -> {
            var o = MinecraftClient.getInstance().options;
            return List.of(
                    "   " + key("W", o.forwardKey.isPressed()),
                    key("A", o.leftKey.isPressed()) + key("S", o.backKey.isPressed()) + key("D", o.rightKey.isPressed()),
                    key("ESPACO", o.jumpKey.isPressed()));
        }));

        l.add(new HudWidget("modlist", "Mods ativos", true, 0.88f, 0.50f, true,
                () -> ModCatalog.get().enabledNames(12)));

        return l;
    }

    /** Busca um widget pelo id (ou null). */
    public static HudWidget byId(String id) {
        for (HudWidget w : all()) if (w.id.equals(id)) return w;
        return null;
    }

    private static String key(String label, boolean pressed) {
        return pressed ? "[" + label + "]" : " " + label + " ";
    }

    /** Volta todos os widgets à posição/escala/estado padrão. */
    public static void resetAll() {
        for (HudWidget w : all()) w.resetState();
        HudConfig.get().markDirty();
    }

    /** Descarta textos em cache (recalculados no próximo frame). */
    public static void invalidate() {
        if (widgets != null) for (HudWidget w : widgets) w.invalidate();
    }

    // ------------------------------------------------------------ HUD no jogo

    /** Desenha os widgets ligados no HUD normal (menu fechado). */
    static void renderInGame(DrawContext g) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.currentScreen instanceof HudScreen) return; // a tela do menu desenha os widgets em modo edição
        Perf.frame();
        Cps.poll(mc.getWindow().getHandle());
        if (mc.options.hudHidden) return;                  // F1
        Gfx.alpha = 1f;
        TextRenderer tr = mc.textRenderer;
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        for (HudWidget w : all()) {
            if (!w.state().enabled) continue;
            w.refresh(tr, false);
            w.draw(g, tr, sw, sh, false, false);
        }
    }
}
