package com.chaos.hud;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;

import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Stream;

/**
 * Índice de receitas do Minecraft para o navegador de itens (JEI).
 *
 * <p>Lê os JSON de receitas e tags que vêm dentro do próprio jogo ({@code data/minecraft/recipe}),
 * então funciona em qualquer modo (um jogador ou servidor) e não depende de o servidor enviar
 * receitas. O carregamento é feito numa thread em segundo plano. Só receitas do Minecraft
 * original (não inclui receitas de outros mods).</p>
 */
public final class RecipeIndex {

    /** Uma receita. {@code slots}: para crafting são 9 posições (vazio = sem item). */
    public static final class Recipe {
        /** crafting, shapeless, smelting, blasting, smoking, campfire, stonecutting, smithing, transmute */
        public final String kind;
        public final String resultId;
        public final int resultCount;
        public final List<List<String>> slots;
        public final int time;

        Recipe(String kind, String resultId, int resultCount, List<List<String>> slots, int time) {
            this.kind = kind;
            this.resultId = resultId;
            this.resultCount = resultCount;
            this.slots = slots;
            this.time = time;
        }
    }

    private static volatile boolean ready, loading;
    private static final Map<String, List<Recipe>> BY_RESULT = new HashMap<>();
    private static final Map<String, List<Recipe>> BY_USE = new HashMap<>();
    private static final Map<String, List<String>> TAGS = new HashMap<>();
    private static Path root;
    private static int total;

    private RecipeIndex() {}

    public static boolean ready() {
        return ready;
    }

    public static int total() {
        return total;
    }

    public static List<Recipe> recipesFor(String itemId) {
        return BY_RESULT.getOrDefault(itemId, List.of());
    }

    public static List<Recipe> usesOf(String itemId) {
        return BY_USE.getOrDefault(itemId, List.of());
    }

    public static boolean hasRecipe(String itemId) {
        return !ready || BY_RESULT.containsKey(itemId);
    }

    /** Inicia o carregamento em segundo plano (uma única vez). */
    public static synchronized void loadAsync() {
        if (loading || ready) return;
        loading = true;
        Thread t = new Thread(RecipeIndex::load, "chaosclient-recipes");
        t.setDaemon(true);
        t.setPriority(Thread.MIN_PRIORITY);
        t.start();
    }

    // ------------------------------------------------------------------ carregamento

    private static void load() {
        try {
            Optional<ModContainer> mod = FabricLoader.getInstance().getModContainer("minecraft");
            if (mod.isPresent()) {
                for (Path r : mod.get().getRootPaths()) {
                    if (Files.isDirectory(r.resolve("data/minecraft/recipe"))) {
                        root = r;
                        break;
                    }
                }
            }
            if (root != null) {
                try (Stream<Path> files = Files.list(root.resolve("data/minecraft/recipe"))) {
                    for (Path p : (Iterable<Path>) files::iterator) {
                        if (p.toString().endsWith(".json")) parse(p);
                    }
                }
            } else {
                System.err.println("[ChaosHud] receitas do Minecraft não encontradas no jar do jogo");
            }
        } catch (Throwable t) {
            System.err.println("[ChaosHud] falha ao carregar receitas: " + t);
        } finally {
            ready = true; // escrita volátil publica os mapas já preenchidos
        }
    }

    private static void parse(Path p) {
        try (Reader r = Files.newBufferedReader(p, StandardCharsets.UTF_8)) {
            JsonObject o = JsonParser.parseReader(r).getAsJsonObject();
            String type = norm(o.get("type").getAsString()).substring("minecraft:".length());
            String[] res = result(o.get("result"));
            if (res == null) return; // receitas especiais sem resultado fixo
            int count = Integer.parseInt(res[1]);

            switch (type) {
                case "crafting_shaped" -> {
                    JsonObject key = o.getAsJsonObject("key");
                    JsonArray pat = o.getAsJsonArray("pattern");
                    List<List<String>> slots = emptySlots();
                    for (int row = 0; row < pat.size() && row < 3; row++) {
                        String s = pat.get(row).getAsString();
                        for (int c = 0; c < s.length() && c < 3; c++) {
                            if (s.charAt(c) == ' ') continue;
                            slots.set(row * 3 + c, ing(key.get(String.valueOf(s.charAt(c))), 0));
                        }
                    }
                    add(new Recipe("crafting", res[0], count, slots, 0));
                }
                case "crafting_shapeless" -> {
                    List<List<String>> slots = emptySlots();
                    JsonArray arr = o.getAsJsonArray("ingredients");
                    for (int i = 0; i < arr.size() && i < 9; i++) slots.set(i, ing(arr.get(i), 0));
                    add(new Recipe("shapeless", res[0], count, slots, 0));
                }
                case "smelting" -> add(cooking("smelting", o, res, count, 200));
                case "blasting" -> add(cooking("blasting", o, res, count, 100));
                case "smoking" -> add(cooking("smoking", o, res, count, 100));
                case "campfire_cooking" -> add(cooking("campfire", o, res, count, 600));
                case "stonecutting" -> add(new Recipe("stonecutting", res[0], count,
                        List.of(ing(o.get("ingredient"), 0)), 0));
                case "smithing_transform" -> add(new Recipe("smithing", res[0], count,
                        List.of(ing(o.get("template"), 0), ing(o.get("base"), 0), ing(o.get("addition"), 0)), 0));
                case "crafting_transmute" -> add(new Recipe("transmute", res[0], count,
                        List.of(ing(o.get("input"), 0), ing(o.get("material"), 0)), 0));
                default -> { /* tipos sem layout simples são ignorados */ }
            }
        } catch (Throwable ignored) {
            // arquivo de formato inesperado: ignora só esta receita
        }
    }

    private static Recipe cooking(String kind, JsonObject o, String[] res, int count, int defTime) {
        int time = o.has("cookingtime") ? o.get("cookingtime").getAsInt() : defTime;
        return new Recipe(kind, res[0], count, List.of(ing(o.get("ingredient"), 0)), time);
    }

    private static void add(Recipe r) {
        total++;
        BY_RESULT.computeIfAbsent(r.resultId, k -> new ArrayList<>()).add(r);
        Set<String> used = new HashSet<>();
        for (List<String> slot : r.slots) used.addAll(slot);
        for (String id : used) BY_USE.computeIfAbsent(id, k -> new ArrayList<>()).add(r);
    }

    private static List<List<String>> emptySlots() {
        List<List<String>> l = new ArrayList<>(9);
        for (int i = 0; i < 9; i++) l.add(List.of());
        return l;
    }

    /** Resultado: {id, quantidade} ou null se não houver. */
    private static String[] result(JsonElement e) {
        if (e == null || e.isJsonNull()) return null;
        if (e.isJsonPrimitive()) return new String[]{norm(e.getAsString()), "1"};
        JsonObject o = e.getAsJsonObject();
        JsonElement id = o.has("id") ? o.get("id") : o.get("item");
        if (id == null) return null;
        return new String[]{norm(id.getAsString()), o.has("count") ? String.valueOf(o.get("count").getAsInt()) : "1"};
    }

    // --------------------------------------------------------- ingredientes e tags

    private static List<String> ing(JsonElement e, int depth) {
        List<String> out = new ArrayList<>();
        if (e == null || e.isJsonNull() || depth > 6) return out;
        if (e.isJsonPrimitive()) {
            String s = e.getAsString();
            if (s.startsWith("#")) out.addAll(tag(norm(s.substring(1)), 0));
            else out.add(norm(s));
        } else if (e.isJsonArray()) {
            for (JsonElement x : e.getAsJsonArray()) out.addAll(ing(x, depth + 1));
        } else if (e.isJsonObject()) {
            JsonObject o = e.getAsJsonObject();
            if (o.has("item")) out.add(norm(o.get("item").getAsString()));
            else if (o.has("tag")) out.addAll(tag(norm(o.get("tag").getAsString()), 0));
        }
        return out;
    }

    private static List<String> tag(String id, int depth) {
        List<String> cached = TAGS.get(id);
        if (cached != null) return cached;
        List<String> out = new ArrayList<>();
        if (root != null && depth < 8) {
            String ns = id.substring(0, id.indexOf(':')), path = id.substring(id.indexOf(':') + 1);
            Path f = root.resolve("data/" + ns + "/tags/item/" + path + ".json");
            if (Files.exists(f)) {
                try (Reader r = Files.newBufferedReader(f, StandardCharsets.UTF_8)) {
                    JsonArray values = JsonParser.parseReader(r).getAsJsonObject().getAsJsonArray("values");
                    for (JsonElement v : values) {
                        String s = v.isJsonPrimitive() ? v.getAsString() : v.getAsJsonObject().get("id").getAsString();
                        if (s.startsWith("#")) out.addAll(tag(norm(s.substring(1)), depth + 1));
                        else out.add(norm(s));
                    }
                } catch (Throwable ignored) {
                    // tag ilegível: fica vazia
                }
            }
        }
        TAGS.put(id, out);
        return out;
    }

    private static String norm(String id) {
        return id.indexOf(':') >= 0 ? id : "minecraft:" + id;
    }
}
