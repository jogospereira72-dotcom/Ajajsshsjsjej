package com.chaos.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.joml.Matrix3x2fStack;
import org.lwjgl.glfw.GLFW;

import java.util.*;

/**
 * Navegador de itens no estilo JEI (tecla J dentro do jogo).
 *
 * <p>Esquerda: grade com todos os itens e busca. Direita: receitas do item selecionado e
 * "usos" (receitas onde ele é ingrediente). Clique em qualquer ingrediente para ir até ele.
 * Digitação da busca é lida direto do teclado (letras, números, espaço, backspace) para não
 * depender de assinaturas de input que mudam entre versões. ESC fecha.</p>
 */
public final class ItemBrowserScreen extends Screen {

    private static final int CELL = 22;

    // cache estático (montado uma vez; os itens do jogo não mudam durante a sessão)
    private static List<String> ids;
    private static String[] names, namesLower, idsNorm;
    private static final Map<String, ItemStack> STACKS = new HashMap<>();

    private final MinecraftClient mc = MinecraftClient.getInstance();
    private final HudConfig cfg = HudConfig.get();
    private final Screen parent;
    private DrawContext g;
    private TextRenderer tr;

    // estado
    private final StringBuilder query = new StringBuilder();
    private final List<Integer> filtered = new ArrayList<>();
    private String lastQuery;
    private boolean lastOnly;
    private int scrollRow;
    private String selected;
    private int mode; // 0 = receitas, 1 = usos
    private int page;
    private final ArrayDeque<String> history = new ArrayDeque<>();

    // entrada
    private int mx, my;
    private boolean down, pressed, prevDown = true;
    private boolean overGrid;
    private final boolean[] prevKey = new boolean[GLFW.GLFW_KEY_LAST + 1];
    private long bsSince, bsLast;
    private String hoverId, clickId;

    public ItemBrowserScreen(Screen parent) {
        super(Text.literal("Navegador de itens"));
        this.parent = parent;
        RecipeIndex.loadAsync();
        ensureItems();
    }

    // ------------------------------------------------------------------ dados

    private static void ensureItems() {
        if (ids != null) return;
        List<String> list = new ArrayList<>();
        for (Item it : Registries.ITEM) {
            if (it != Items.AIR) list.add(Registries.ITEM.getId(it).toString());
        }
        Collections.sort(list);
        names = new String[list.size()];
        namesLower = new String[list.size()];
        idsNorm = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            names[i] = stack(list.get(i)).getName().getString();
            namesLower[i] = names[i].toLowerCase(Locale.ROOT);
            idsNorm[i] = list.get(i).substring(list.get(i).indexOf(':') + 1).replace('_', ' ');
        }
        ids = list;
    }

    private static ItemStack stack(String id) {
        ItemStack s = STACKS.get(id);
        if (s != null) return s;
        Identifier ident = Identifier.tryParse(id);
        s = ident != null && Registries.ITEM.containsId(ident) ? new ItemStack(Registries.ITEM.get(ident)) : ItemStack.EMPTY;
        STACKS.put(id, s);
        return s;
    }

    private static String displayName(String id) {
        ItemStack s = stack(id);
        return s.isEmpty() ? id : s.getName().getString();
    }

    private void refilter() {
        String q = query.toString().toLowerCase(Locale.ROOT).replace('_', ' ').trim();
        filtered.clear();
        for (int i = 0; i < ids.size(); i++) {
            if (cfg.jeiOnlyCraftable && !RecipeIndex.hasRecipe(ids.get(i))) continue;
            if (!q.isEmpty() && !namesLower[i].contains(q) && !idsNorm[i].contains(q)) continue;
            filtered.add(i);
        }
        scrollRow = 0;
        lastQuery = query.toString();
        lastOnly = cfg.jeiOnlyCraftable;
    }

    private void select(String id, boolean push) {
        if (push && selected != null && !id.equals(selected)) history.push(selected);
        selected = id;
        page = 0;
        mode = RecipeIndex.recipesFor(id).isEmpty() && !RecipeIndex.usesOf(id).isEmpty() ? 1 : 0;
    }

    // ----------------------------------------------------------------- ciclo

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        mc.setScreen(parent);
    }

    @Override
    public boolean mouseScrolled(double x, double y, double h, double v) {
        if (overGrid) {
            scrollRow -= (int) Math.round(v) * 2;
            return true;
        }
        return false;
    }

    // ---------------------------------------------------------------- entrada

    private void pollKeys() {
        long h = mc.getWindow().getHandle();
        boolean ctrl = GLFW.glfwGetKey(h, GLFW.GLFW_KEY_LEFT_CONTROL) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(h, GLFW.GLFW_KEY_LEFT_SUPER) == GLFW.GLFW_PRESS;
        for (int k = GLFW.GLFW_KEY_A; k <= GLFW.GLFW_KEY_Z; k++) typed(h, k, (char) ('a' + k - GLFW.GLFW_KEY_A), ctrl);
        for (int k = GLFW.GLFW_KEY_0; k <= GLFW.GLFW_KEY_9; k++) typed(h, k, (char) ('0' + k - GLFW.GLFW_KEY_0), ctrl);
        typed(h, GLFW.GLFW_KEY_SPACE, ' ', ctrl);
        typed(h, GLFW.GLFW_KEY_MINUS, '_', ctrl);

        boolean bs = GLFW.glfwGetKey(h, GLFW.GLFW_KEY_BACKSPACE) == GLFW.GLFW_PRESS;
        long now = System.currentTimeMillis();
        if (bs) {
            if (!prevKey[GLFW.GLFW_KEY_BACKSPACE]) {
                bsSince = now;
                bsLast = now;
                deleteChar();
            } else if (now - bsSince > 400 && now - bsLast > 40) { // repetição ao segurar
                bsLast = now;
                deleteChar();
            }
        }
        prevKey[GLFW.GLFW_KEY_BACKSPACE] = bs;
    }

    private void typed(long h, int key, char ch, boolean ctrl) {
        boolean d = GLFW.glfwGetKey(h, key) == GLFW.GLFW_PRESS;
        if (d && !prevKey[key] && !ctrl && query.length() < 40) query.append(ch);
        prevKey[key] = d;
    }

    private void deleteChar() {
        if (query.length() > 0) query.setLength(query.length() - 1);
    }

    // ----------------------------------------------------------------- render

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        g = ctx;
        tr = mc.textRenderer;
        mx = mouseX;
        my = mouseY;
        Gfx.alpha = 1f;
        Perf.frame();
        hoverId = null;
        clickId = null;

        long hnd = mc.getWindow().getHandle();
        down = GLFW.glfwGetMouseButton(hnd, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        pressed = down && !prevDown;
        prevDown = down;
        pollKeys();
        if (lastQuery == null || !lastQuery.equals(query.toString()) || lastOnly != cfg.jeiOnlyCraftable) refilter();

        int accent = cfg.accent;
        int pw = Math.min(width - 24, 660), ph = Math.min(height - 24, 380);
        int px = (width - pw) / 2, py = (height - ph) / 2;
        int leftW = (int) (pw * 0.5f);

        g.fill(0, 0, width, height, Gfx.rgba(0x000000, 0.45f));
        Gfx.glass(g, px, py, pw, ph, 8, 0.9f, cfg);

        // título
        Gfx.text(g, tr, "§lNAVEGADOR DE ITENS", px + 12, py + 9, accent, 1f, false);
        String info = RecipeIndex.ready() ? filtered.size() + " itens | " + RecipeIndex.total() + " receitas" : "Carregando receitas...";
        Gfx.text(g, tr, info, px + leftW - 12 - tr.getWidth(info), py + 9, 0x8A90A0, 1f, false);
        if (button(px + pw - 26, py + 6, 14, 14, "x", false)) close();

        // busca + filtro
        float sx = px + 12, sy = py + 28, sw = leftW - 24 - 78;
        Gfx.roundRect(g, sx, sy, sw, 18, 4, Gfx.rgba(0xFFFFFF, 0.08f));
        String shown = query.length() == 0 ? "Buscar item... (digite)" : query.toString();
        boolean cursor = (System.currentTimeMillis() / 500) % 2 == 0;
        Gfx.text(g, tr, Perf.ellipsize(tr, shown, (int) sw - 18) + (query.length() > 0 && cursor ? "_" : ""),
                sx + 6, sy + 5, query.length() == 0 ? 0x6A7080 : 0xE6E9F2, 1f, false);
        if (button(sx + sw + 6, sy, 72, 18, "Só craftáveis", cfg.jeiOnlyCraftable)) {
            cfg.jeiOnlyCraftable = !cfg.jeiOnlyCraftable;
            cfg.markDirty();
        }

        drawGrid(px + 12, py + 54, leftW - 24, ph - 54 - 12);

        // divisor
        Gfx.fill(g, px + leftW, py + 28, 1, ph - 40, Gfx.rgba(0xFFFFFF, 0.10f));
        drawRecipePanel(px + leftW + 12, py + 28, pw - leftW - 24, ph - 40);

        // clique em ingrediente (aplicado depois do desenho)
        if (clickId != null) select(clickId, true);
        drawTooltip();
    }

    // ------------------------------------------------------------------ grade

    private void drawGrid(int gx, int gy, int gw, int gh) {
        int cols = Math.max(1, gw / CELL);
        int rowsVisible = Math.max(1, gh / CELL);
        int rowsTotal = (filtered.size() + cols - 1) / cols;
        scrollRow = Math.max(0, Math.min(scrollRow, Math.max(0, rowsTotal - rowsVisible)));
        overGrid = mx >= gx && mx < gx + gw && my >= gy && my < gy + gh;

        for (int r = 0; r < rowsVisible; r++) {
            for (int c = 0; c < cols; c++) {
                int idx = (scrollRow + r) * cols + c;
                if (idx >= filtered.size()) break;
                String id = ids.get(filtered.get(idx));
                float x = gx + c * CELL, y = gy + r * CELL;
                boolean hov = mx >= x && mx < x + 20 && my >= y && my < y + 20;
                boolean sel = id.equals(selected);
                Gfx.roundRect(g, x, y, 20, 20, 3, Gfx.rgba(sel ? cfg.accent : 0xFFFFFF, sel ? 0.35f : hov ? 0.18f : 0.07f));
                ItemStack st = stack(id);
                if (!st.isEmpty()) g.drawItem(st, (int) x + 2, (int) y + 2);
                if (hov) {
                    hoverId = id;
                    if (pressed) select(id, false);
                }
            }
        }
        if (filtered.isEmpty()) Gfx.text(g, tr, "Nenhum item encontrado", gx + 4, gy + 6, 0x8A90A0, 1f, false);

        // barra de rolagem
        if (rowsTotal > rowsVisible) {
            float trackH = rowsVisible * CELL;
            float thumbH = Math.max(14f, trackH * rowsVisible / rowsTotal);
            float p = (float) scrollRow / (rowsTotal - rowsVisible);
            Gfx.roundRect(g, gx + gw + 3, gy, 3, trackH, 1, Gfx.rgba(0xFFFFFF, 0.06f));
            Gfx.roundRect(g, gx + gw + 3, gy + p * (trackH - thumbH), 3, thumbH, 1, Gfx.rgba(cfg.accent, 0.6f));
        }
    }

    // ------------------------------------------------------------- painel de receitas

    private void drawRecipePanel(int rx, int ry, int rw, int rh) {
        if (selected == null) {
            Gfx.text(g, tr, "Clique em um item para ver", rx, ry + 8, 0x8A90A0, 1f, false);
            Gfx.text(g, tr, "como fazer (e onde é usado).", rx, ry + 20, 0x8A90A0, 1f, false);
            return;
        }
        // cabeçalho: ícone grande + nome
        ItemStack st = stack(selected);
        if (!st.isEmpty()) {
            Matrix3x2fStack m = g.getMatrices();
            m.pushMatrix();
            m.translate(rx, ry + 2);
            m.scale(2f, 2f);
            g.drawItem(st, 0, 0);
            m.popMatrix();
        }
        Gfx.text(g, tr, Perf.ellipsize(tr, displayName(selected), rw - 44), rx + 40, ry + 6, 0xFFFFFF, 1f, true);
        Gfx.text(g, tr, Perf.ellipsize(tr, selected, rw - 44), rx + 40, ry + 18, 0x8A90A0, 1f, false);

        List<RecipeIndex.Recipe> rec = RecipeIndex.recipesFor(selected), uses = RecipeIndex.usesOf(selected);
        float by = ry + 40;
        if (!history.isEmpty() && button(rx + rw - 54, ry + 2, 54, 16, "< Voltar", false)) select(history.pop(), false);
        if (button(rx, by, 86, 16, "Receitas (" + rec.size() + ")", mode == 0)) { mode = 0; page = 0; }
        if (button(rx + 92, by, 70, 16, "Usos (" + uses.size() + ")", mode == 1)) { mode = 1; page = 0; }

        if (!RecipeIndex.ready()) {
            Gfx.text(g, tr, "Carregando receitas...", rx, by + 28, 0x8A90A0, 1f, false);
            return;
        }
        List<RecipeIndex.Recipe> list = mode == 0 ? rec : uses;
        if (list.isEmpty()) {
            Gfx.text(g, tr, mode == 0 ? "Sem receita de craft para este item." : "Este item não é ingrediente de receitas.",
                    rx, by + 28, 0x8A90A0, 1f, false);
            return;
        }
        page = Math.max(0, Math.min(page, list.size() - 1));
        if (list.size() > 1) {
            if (button(rx + rw - 62, by, 16, 16, "<", false)) page = (page + list.size() - 1) % list.size();
            Gfx.textC(g, tr, (page + 1) + "/" + list.size(), rx + rw - 28, by + 4, 0xE6E9F2, 1f, false);
            if (button(rx + rw - 16, by, 16, 16, ">", false)) page = (page + 1) % list.size();
        }
        drawRecipe(list.get(page), rx + 6, (int) by + 30);
    }

    private void drawRecipe(RecipeIndex.Recipe r, int ox, int oy) {
        boolean grid = r.kind.equals("crafting") || r.kind.equals("shapeless");
        int arrowX, resultX, resultY;
        if (grid) {
            for (int i = 0; i < 9; i++) slot(ox + (i % 3) * CELL, oy + (i / 3) * CELL, r.slots.get(i), 0);
            arrowX = ox + 3 * CELL + 8;
            resultX = arrowX + 30;
            resultY = oy + CELL;
        } else {
            for (int i = 0; i < r.slots.size(); i++) slot(ox + i * CELL, oy + CELL, r.slots.get(i), 0);
            arrowX = ox + r.slots.size() * CELL + 8;
            resultX = arrowX + 30;
            resultY = oy + CELL;
        }
        Gfx.text(g, tr, "§l->", arrowX, resultY + 6, cfg.accent, 1f, false);
        slot(resultX, resultY, List.of(r.resultId), r.resultCount);

        String label = switch (r.kind) {
            case "crafting" -> "Mesa de trabalho (formato fixo)";
            case "shapeless" -> "Mesa de trabalho (sem formato)";
            case "smelting" -> "Fornalha - " + (r.time / 20) + "s";
            case "blasting" -> "Alto-forno - " + (r.time / 20) + "s";
            case "smoking" -> "Defumador - " + (r.time / 20) + "s";
            case "campfire" -> "Fogueira - " + (r.time / 20) + "s";
            case "stonecutting" -> "Cortador de pedra";
            case "smithing" -> "Mesa de ferraria (molde, base, adição)";
            default -> "Receita especial";
        };
        Gfx.text(g, tr, label, ox, oy + (grid ? 3 * CELL + 8 : 2 * CELL + 10), 0x8A90A0, 1f, false);
    }

    private void slot(float x, float y, List<String> cands, int count) {
        boolean hov = mx >= x && mx < x + 20 && my >= y && my < y + 20;
        Gfx.roundRect(g, x, y, 20, 20, 3, Gfx.rgba(0xFFFFFF, hov ? 0.16f : 0.08f));
        if (cands == null || cands.isEmpty()) return;
        String id = cands.get((int) ((System.currentTimeMillis() / 900) % cands.size())); // tags alternam entre os itens
        ItemStack st = stack(id);
        if (st.isEmpty()) return;
        g.drawItem(st, (int) x + 2, (int) y + 2);
        if (count > 1) {
            String c = String.valueOf(count);
            Gfx.text(g, tr, c, x + 19 - tr.getWidth(c), y + 11, 0xFFFFFF, 1f, true);
        }
        if (hov) {
            hoverId = id;
            if (pressed) clickId = id;
        }
    }

    // ---------------------------------------------------------------- utilidades

    /** Botão simples; retorna true no frame do clique. */
    private boolean button(float x, float y, float w, float h, String label, boolean active) {
        boolean hov = mx >= x && mx < x + w && my >= y && my < y + h;
        Gfx.roundRect(g, x, y, w, h, 4, active ? Gfx.rgba(cfg.accent, 0.8f) : Gfx.rgba(0xFFFFFF, hov ? 0.16f : 0.08f));
        Gfx.textC(g, tr, label, x + w / 2f, y + (h - 8) / 2f, active ? 0x0B0E14 : 0xE6E9F2, 1f, false);
        return hov && pressed;
    }

    private void drawTooltip() {
        if (hoverId == null) return;
        String n = displayName(hoverId);
        int w = Math.max(tr.getWidth(n), tr.getWidth(hoverId)) + 12;
        float x = Math.min(mx + 10, width - w - 4), y = Math.max(4, my - 8);
        Gfx.glass(g, x, y, w, 26, 4, 0.95f, cfg);
        Gfx.text(g, tr, n, x + 6, y + 4, 0xFFFFFF, 1f, false);
        Gfx.text(g, tr, hoverId, x + 6, y + 14, 0x8A90A0, 1f, false);
    }
}
