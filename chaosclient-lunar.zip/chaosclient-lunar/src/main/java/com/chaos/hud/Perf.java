package com.chaos.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.ParticlesMode;
import net.minecraft.client.option.SimpleOption;

import java.util.*;

/**
 * Otimizações de desempenho do HUD.
 *
 * <ol>
 *   <li><b>Contador de FPS próprio</b>: conta frames desenhados, sem depender de API do jogo.</li>
 *   <li><b>Ajustes temporários de opções</b>: enquanto o menu está aberto (e/ou o mod FPS Boost
 *       está ligado) reduz partículas, distância de entidades e limita o FPS máximo. As opções
 *       originais são guardadas e restauradas ao fechar o menu, desligar o mod e ao sair do jogo.</li>
 *   <li><b>Caches de texto</b> (reticências e quebra de linha) com limite de tamanho, limpos
 *       ao fechar o menu.</li>
 * </ol>
 */
public final class Perf {

    private Perf() {}

    // ------------------------------------------------------------ contador de FPS

    private static int frames;
    private static long lastNs = System.nanoTime();
    private static int fps;

    /** Chamar uma vez por frame desenhado. */
    public static void frame() {
        frames++;
        long now = System.nanoTime();
        long dt = now - lastNs;
        if (dt >= 500_000_000L) {
            fps = (int) Math.round(frames * 1e9 / dt);
            frames = 0;
            lastNs = now;
        }
    }

    public static int fps() {
        return fps;
    }

    // --------------------------------------------------------------------- caches

    private static final Map<String, String> ELLIPSIS = new HashMap<>();
    private static final Map<String, List<String>> WRAP = new HashMap<>();

    /** Corta o texto com "..." para caber em {@code maxW} pixels (resultado em cache). */
    public static String ellipsize(TextRenderer tr, String s, int maxW) {
        if (tr.getWidth(s) <= maxW) return s;
        String key = maxW + "|" + s;
        String cached = ELLIPSIS.get(key);
        if (cached != null) return cached;
        if (ELLIPSIS.size() > 1024) ELLIPSIS.clear();
        String out = s;
        while (out.length() > 1 && tr.getWidth(out + "...") > maxW) out = out.substring(0, out.length() - 1);
        out = out + "...";
        ELLIPSIS.put(key, out);
        return out;
    }

    /** Quebra o texto em linhas de no máximo {@code maxW} pixels (resultado em cache). */
    public static List<String> wrap(TextRenderer tr, String s, int maxW) {
        String key = maxW + "|" + s;
        List<String> cached = WRAP.get(key);
        if (cached != null) return cached;
        if (WRAP.size() > 256) WRAP.clear();
        List<String> lines = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String word : s.split(" ")) {
            String test = cur.length() == 0 ? word : cur + " " + word;
            if (cur.length() > 0 && tr.getWidth(test) > maxW) {
                lines.add(cur.toString());
                cur = new StringBuilder(word);
            } else {
                cur = new StringBuilder(test);
            }
        }
        if (cur.length() > 0) lines.add(cur.toString());
        WRAP.put(key, lines);
        return lines;
    }

    /** Limpa caches visuais (textos e linhas dos widgets). */
    public static void clearCaches() {
        ELLIPSIS.clear();
        WRAP.clear();
        WidgetRegistry.invalidate();
    }

    /** Chamado quando o menu fecha: limpeza opcional de memória. */
    public static void onMenuClosed(HudConfig cfg) {
        if (cfg.clearCachesOnClose) clearCaches();
        if (cfg.gcOnClose) System.gc(); // sugestão ao coletor; pode causar um pequeno engasgo
    }

    public static long usedMb() {
        Runtime r = Runtime.getRuntime();
        return (r.totalMemory() - r.freeMemory()) / (1024 * 1024);
    }

    public static long maxMb() {
        return Runtime.getRuntime().maxMemory() / (1024 * 1024);
    }

    // ---------------------------------------------- ajustes temporários de opções

    private static boolean snapshot;
    private static ParticlesMode origParticles;
    private static double origEntity;
    private static int origFps;
    private static int lastSig;

    /**
     * Recalcula quais ajustes devem estar ativos e aplica/restaura as opções do jogo.
     * Só escreve nas opções quando o valor realmente muda.
     *
     * @param menuOpen true enquanto o menu do ChaosClient está aberto
     */
    public static void update(MinecraftClient mc, boolean menuOpen) {
        if (mc == null || mc.options == null) return;
        GameOptions o = mc.options;
        HudConfig c = HudConfig.get();
        FpsBoostMod boost = FpsBoostMod.INSTANCE;
        boolean boostOn = boost != null && boost.isEnabled();

        boolean wantParticles = (menuOpen && c.perfParticles) || (boostOn && boost.reduceParticles());
        Double wantEntity = menuOpen && c.perfEntities ? Double.valueOf(0.5) : null;
        if (boostOn) {
            double b = boost.entityScale();
            wantEntity = wantEntity == null ? b : Math.min(wantEntity, b);
        }
        Integer wantFps = menuOpen && c.perfFpsCap ? Integer.valueOf(c.perfFpsCapValue) : null;
        boolean any = wantParticles || wantEntity != null || wantFps != null;

        if (any && !snapshot) {
            origParticles = o.getParticles().getValue();
            origEntity = o.getEntityDistanceScaling().getValue();
            origFps = o.getMaxFps().getValue();
            snapshot = true;
        }
        if (!snapshot) return;

        set(o.getParticles(), wantParticles ? ParticlesMode.MINIMAL : origParticles);
        set(o.getEntityDistanceScaling(), wantEntity != null ? Math.min(origEntity, wantEntity) : origEntity);
        set(o.getMaxFps(), wantFps != null ? Math.min(origFps, wantFps) : origFps);

        if (!any) snapshot = false;
    }

    private static <T> void set(SimpleOption<T> opt, T value) {
        if (!opt.getValue().equals(value)) opt.setValue(value);
    }

    /** Detecta mudança nas settings do FPS Boost (ex.: slider) e reaplica. Chamar a cada ~10 ticks. */
    public static void tick(MinecraftClient mc) {
        FpsBoostMod b = FpsBoostMod.INSTANCE;
        if (b == null) return;
        int sig = b.signature();
        if (sig != lastSig) {
            lastSig = sig;
            update(mc, mc.currentScreen instanceof HudScreen);
        }
    }

    /**
     * Perfil "Max FPS": grava de forma permanente (options.txt) as opções que mais pesam
     * no desempenho. Só reduz valores (nunca aumenta) para não piorar quem já usa menos.
     */
    public static void applyFpsProfile(MinecraftClient mc) {
        if (mc == null || mc.options == null) return;
        restoreAll(mc); // desfaz ajustes temporários antes, para não gravá-los por engano
        GameOptions o = mc.options;
        set(o.getViewDistance(), Math.min(o.getViewDistance().getValue(), 10));
        set(o.getSimulationDistance(), Math.min(o.getSimulationDistance().getValue(), 6));
        set(o.getEntityDistanceScaling(), Math.min(o.getEntityDistanceScaling().getValue(), 0.75));
        set(o.getParticles(), ParticlesMode.DECREASED);
        set(o.getEntityShadows(), false);
        set(o.getBiomeBlendRadius(), Math.min(o.getBiomeBlendRadius().getValue(), 1));
        set(o.getMaxFps(), 260); // 260 = ilimitado
        set(o.getEnableVsync(), false);
        o.write();
    }

    /** Restaura tudo imediatamente (usado ao sair do jogo, para não gravar opções alteradas). */
    public static void restoreAll(MinecraftClient mc) {
        if (!snapshot || mc == null || mc.options == null) return;
        GameOptions o = mc.options;
        set(o.getParticles(), origParticles);
        set(o.getEntityDistanceScaling(), origEntity);
        set(o.getMaxFps(), origFps);
        snapshot = false;
    }
}
