#!/usr/bin/env python3
"""
Monta o "Pack ChaosClient": o seu JAR + mods de desempenho baixados do Modrinth
(sempre a versão mais recente para o Minecraft/loader abaixo). Roda no GitHub Actions.
Saída: dist/ChaosClient-Pack-<MC>.zip  (pasta mods/ pronta para copiar)
"""
import glob, hashlib, json, os, shutil, sys, urllib.parse, urllib.request, zipfile

MC = os.environ.get("MC_VERSION", "1.21.11")
LOADER = "fabric"
# slug no Modrinth -> obrigatório?
MODS = {
    "fabric-api": True,       # exigido pelo ChaosClient
    "sodium": True,           # motor de renderização: o maior ganho de FPS
    "lithium": False,         # otimiza lógica do jogo (servidor integrado, colisões, IA)
    "ferrite-core": False,    # reduz uso de memória
    "entityculling": False,   # não desenha entidades/bloqueios que você não vê
    "immediatelyfast": False, # acelera renderização de HUD, texto e GUI
}
UA = {"User-Agent": "chaosclient-bundle/1.0 (github actions)"}

def get(url):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=60) as r:
        return r.read()

def latest(slug):
    q = urllib.parse.urlencode({
        "loaders": json.dumps([LOADER]),
        "game_versions": json.dumps([MC]),
    })
    versions = json.loads(get(f"https://api.modrinth.com/v2/project/{slug}/version?{q}"))
    if not versions:
        return None
    releases = [v for v in versions if v.get("version_type") == "release"]
    return (releases or versions)[0]

def main():
    out = "dist/pack/mods"
    shutil.rmtree("dist", ignore_errors=True)
    os.makedirs(out)
    missing = []
    for slug, required in MODS.items():
        try:
            v = latest(slug)
            if not v:
                raise RuntimeError(f"sem versão para {MC}/{LOADER}")
            f = next((x for x in v["files"] if x.get("primary")), v["files"][0])
            data = get(f["url"])
            want = f["hashes"].get("sha512")
            if want and hashlib.sha512(data).hexdigest() != want:
                raise RuntimeError("hash sha512 não confere")
            with open(os.path.join(out, f["filename"]), "wb") as fh:
                fh.write(data)
            print(f"OK   {slug}: {f['filename']}")
        except Exception as e:
            print(f"FALHOU {slug}: {e}", file=sys.stderr)
            missing.append((slug, required))

    jars = [j for j in glob.glob("build/libs/*.jar") if not j.endswith("-sources.jar")]
    if not jars:
        sys.exit("JAR do ChaosClient não encontrado em build/libs")
    for j in jars:
        shutil.copy(j, out)

    with open("dist/pack/LEIA-ME.txt", "w", encoding="utf-8") as fh:
        fh.write(
            f"ChaosClient Pack - Minecraft {MC} (Fabric)\n\n"
            "1. Instale o Fabric Loader para este Minecraft (fabricmc.net/use ou Prism Launcher).\n"
            "2. Copie TODOS os .jar da pasta mods/ para .minecraft/mods (ou a pasta mods da sua instância).\n"
            "3. Abra o jogo. Dentro de um mundo, aperte X para o menu.\n\n"
            "Mods de desempenho incluídos: Sodium, Lithium, FerriteCore, EntityCulling, ImmediatelyFast.\n"
        )
        for slug, req in missing:
            fh.write(f"\nAVISO: {slug} não pôde ser baixado" + (" (OBRIGATÓRIO)" if req else "") + ".\n")

    zname = f"dist/ChaosClient-Pack-{MC}.zip"
    with zipfile.ZipFile(zname, "w", zipfile.ZIP_DEFLATED) as z:
        for root, _, files in os.walk("dist/pack"):
            for fn in files:
                p = os.path.join(root, fn)
                z.write(p, os.path.relpath(p, "dist/pack"))
    print("Gerado", zname)
    if any(req for _, req in missing):
        sys.exit("Faltou um mod obrigatório; veja os erros acima.")

if __name__ == "__main__":
    main()
