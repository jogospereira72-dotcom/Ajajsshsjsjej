package net.ratman.modmenu;

public class SettingsManager {
    private static SettingsManager instance;

    // Menu settings
    public boolean menuEnabled = true;
    public boolean menuVisible = true;
    public float menuOpacity = 1.0f;
    public int menuX = 20;
    public int menuY = 20;
    public boolean menuDraggable = true;

    // Visual settings
    public boolean showHUD = true;
    public int hudColor = 0xFF00FF00;
    public float hudScale = 1.0f;

    // Feature settings
    public boolean autoDisableOnDeath = false;
    public boolean hideMenuInSpectator = false;
    public int menuKeybind = 77; // M key GLFW code

    public static SettingsManager getInstance() {
        if (instance == null) instance = new SettingsManager();
        return instance;
    }

    public void toggleMenu() {
        menuEnabled = !menuEnabled;
    }

    public void setMenuPosition(int x, int y) {
        this.menuX = x;
        this.menuY = y;
    }

    public void setMenuOpacity(float opacity) {
        this.menuOpacity = Math.max(0.1f, Math.min(1.0f, opacity));
    }

    public void saveSettings() {
        // TODO: Persist to config file
    }

    public void loadSettings() {
        // TODO: Load from config file
    }
}
