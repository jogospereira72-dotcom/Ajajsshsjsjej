package net.ratman.chaosclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.ratman.chaosclient.features.FeatureExecutor;
import org.lwjgl.glfw.GLFW;

public class ModMenuMod implements ClientModInitializer {
    public static KeyBinding menuKey;

    @Override
    public void onInitializeClient() {
        menuKey = KeyBindingHelper.registerKeyBinding(
            new KeyBinding("key.chaosclient.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_M, "category.chaosclient")
        );

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new ModMenuScreen40());
                } else if (client.currentScreen instanceof ModMenuScreen40) {
                    client.setScreen(null);
                }
            }
            // Tick all 40 features
            FeatureExecutor.getInstance().tickAllFeatures();

            // ESC key for settings
            if (client.currentScreen != null && client.currentScreen instanceof ModMenuScreen40) {
                // Settings accessible from main menu
            }
        });

        // Register ESC key handler for settings
        ScreenKeyboardEvents.beforeKeyPress().register((screen, key, scanCode, modifiers) -> {
            if (key == GLFW.GLFW_KEY_ESCAPE && screen instanceof ModMenuScreen40) {
                SettingsManager.getInstance().saveSettings();
                return false; // Don't consume the event
            }
            if (key == GLFW.GLFW_KEY_ESCAPE && !(screen instanceof SettingsScreen)) {
                // Open settings from anywhere by pressing ESC twice rapidly
                return false;
            }
            return false;
        });
    }
}
