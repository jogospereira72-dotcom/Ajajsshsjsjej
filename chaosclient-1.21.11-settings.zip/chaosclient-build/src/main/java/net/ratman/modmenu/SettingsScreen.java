package net.ratman.modmenu;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class SettingsScreen extends Screen {
    private int menuX, menuY, menuWidth = 300, menuHeight = 450;
    private SettingsManager settings = SettingsManager.getInstance();

    private float opacitySlider = 1.0f;
    private boolean dragging = false;

    public SettingsScreen() {
        super(Text.literal("ChaosClient Settings"));
        this.menuX = 50;
        this.menuY = 50;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderDarkening(context);

        // Panel background
        context.fill(menuX, menuY, menuX + menuWidth, menuY + menuHeight, 0xAA1a1a1a);
        // Border
        context.fill(menuX, menuY, menuX + menuWidth, menuY + 2, 0xFF00FF00);
        context.fill(menuX, menuY, menuX + 2, menuY + menuHeight, 0xFF00FF00);
        context.fill(menuX + menuWidth - 2, menuY, menuX + menuWidth, menuY + menuHeight, 0xFF00FF00);
        context.fill(menuX, menuY + menuHeight - 2, menuX + menuWidth, menuY + menuHeight, 0xFF00FF00);

        // Title bar
        context.fill(menuX, menuY, menuX + menuWidth, menuY + 30, 0xFF000000);
        context.drawTextWithShadow(this.textRenderer, "SETTINGS", menuX + 10, menuY + 10, 0x00FF00);

        // Settings content
        int settingY = menuY + 45;
        int settingX = menuX + 15;
        int settingW = menuWidth - 30;

        // Menu enabled toggle
        drawSettingToggle(context, settingX, settingY, settingW,
                         "Menu Enabled", settings.menuEnabled, 0);
        settingY += 25;

        // Menu visible toggle
        drawSettingToggle(context, settingX, settingY, settingW,
                         "Menu Visible", settings.menuVisible, 1);
        settingY += 25;

        // Auto-disable on death
        drawSettingToggle(context, settingX, settingY, settingW,
                         "Auto-disable on Death", settings.autoDisableOnDeath, 2);
        settingY += 25;

        // Hide in spectator
        drawSettingToggle(context, settingX, settingY, settingW,
                         "Hide in Spectator", settings.hideMenuInSpectator, 3);
        settingY += 25;

        // Menu opacity slider
        context.drawTextWithShadow(this.textRenderer, "Menu Opacity", settingX, settingY, 0xFFFFFF);
        settingY += 15;
        drawSlider(context, settingX, settingY, settingW, settings.menuOpacity);
        settingY += 20;

        // Menu draggable
        drawSettingToggle(context, settingX, settingY, settingW,
                         "Menu Draggable", settings.menuDraggable, 4);
        settingY += 30;

        // Info section
        context.fill(settingX - 5, settingY, settingX + settingW + 5, settingY + 80, 0x44000000);
        context.drawTextWithShadow(this.textRenderer, "Menu Controls:", settingX, settingY + 5, 0x00FF00);
        context.drawTextWithShadow(this.textRenderer, "M - Open/Close Menu", settingX + 10, settingY + 18, 0xFFCCCCCC);
        context.drawTextWithShadow(this.textRenderer, "ESC - Settings (this menu)", settingX + 10, settingY + 31, 0xFFCCCCCC);
        context.drawTextWithShadow(this.textRenderer, "Click & Drag - Move Menu", settingX + 10, settingY + 44, 0xFFCCCCCC);
        context.drawTextWithShadow(this.textRenderer, "Close - ESC or click outside", settingX + 10, settingY + 57, 0xFFCCCCCC);

        super.render(context, mouseX, mouseY, delta);
    }

    private void drawSettingToggle(DrawContext context, int x, int y, int w, String label, boolean enabled, int id) {
        int color = enabled ? 0xFF00FF00 : 0xFF884400;
        String status = enabled ? "ON" : "OFF";

        context.fill(x, y, x + w, y + 18, color);
        context.drawTextWithShadow(this.textRenderer, label + ": " + status, x + 5, y + 5, 0xFFFFFF);
    }

    private void drawSlider(DrawContext context, int x, int y, int w, float value) {
        // Slider background
        context.fill(x, y, x + w, y + 10, 0xFF444444);

        // Slider fill
        int fillWidth = (int)(w * value);
        context.fill(x, y, x + fillWidth, y + 10, 0xFF00FF00);

        // Slider thumb
        int thumbX = (int)(x + (w * value));
        context.fill(thumbX - 3, y - 2, thumbX + 3, y + 12, 0xFFFFFFFF);

        // Value text
        context.drawTextWithShadow(this.textRenderer, String.format("%.0f%%", value * 100), x + w + 10, y - 2, 0xFFFFFF);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            // Check toggle buttons
            int settingY = menuY + 45;
            int settingX = menuX + 15;
            int settingW = menuWidth - 30;

            // Menu enabled
            if (mouseX > settingX && mouseX < settingX + settingW && mouseY > settingY && mouseY < settingY + 18) {
                settings.menuEnabled = !settings.menuEnabled;
                return true;
            }
            settingY += 25;

            // Menu visible
            if (mouseX > settingX && mouseX < settingX + settingW && mouseY > settingY && mouseY < settingY + 18) {
                settings.menuVisible = !settings.menuVisible;
                return true;
            }
            settingY += 25;

            // Auto-disable on death
            if (mouseX > settingX && mouseX < settingX + settingW && mouseY > settingY && mouseY < settingY + 18) {
                settings.autoDisableOnDeath = !settings.autoDisableOnDeath;
                return true;
            }
            settingY += 25;

            // Hide in spectator
            if (mouseX > settingX && mouseX < settingX + settingW && mouseY > settingY && mouseY < settingY + 18) {
                settings.hideMenuInSpectator = !settings.hideMenuInSpectator;
                return true;
            }
            settingY += 25;

            // Opacity slider
            if (mouseX > settingX && mouseX < settingX + settingW && mouseY > settingY + 15 && mouseY < settingY + 25) {
                float sliderPercent = (float)(mouseX - settingX) / settingW;
                settings.setMenuOpacity(sliderPercent);
                return true;
            }
            settingY += 20;

            // Menu draggable
            if (mouseX > settingX && mouseX < settingX + settingW && mouseY > settingY && mouseY < settingY + 18) {
                settings.menuDraggable = !settings.menuDraggable;
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) { // ESC key
            this.close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void close() {
        settings.saveSettings();
        this.client.setScreen(null);
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return true;
    }
}
